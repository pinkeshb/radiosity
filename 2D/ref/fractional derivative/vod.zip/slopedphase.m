function [C, slope] = slopedphase(wl, wh, coefzeros, coefpoles)
% function [C, slope] = slopedphase(wl, wh, coefzeros, coefpoles)
% Finds a Crone approximation of a complex order derivative with a linear phase.
% C is the approximation, slope is the slope of the phase in degrees/decade.
% Zeros and poles are recursively placed in the [wl,wh] rad/s range.
% The recursivity coefficients are also given.
% Zeros (for negative slopes) or poles (for positive slopes) will also be
% placed outside the [wl,wh] range to the extent needed to ensure a causal system.
% The phase of C will be 0 for w=1 rad/s.
% Duarte Val�rio 2010

nzeros_2 = ceil( log(wh/wl) / log(abs(coefzeros)) / 2 );
npoles_2 = ceil( log(wh/wl) / log(abs(coefpoles)) / 2 );
nzeros_2 = max([nzeros_2 npoles_2]); npoles_2 = nzeros_2;
w0 = sqrt(wl*wh);
powzeros = -nzeros_2-0.5 : nzeros_2+0.5;
powpoles = -npoles_2-0.5 : npoles_2+0.5;
Cz = w0 * coefzeros.^powzeros;
Cp = w0 * coefpoles.^powpoles;
% if length(Cz)>length(Cp)
%     Cp = [Cp, 10*wh*ones(1, length(Cz)-length(Cp))];
% end
C = tf(zpk(-Cz, -Cp, 1));
slope = rad2deg( pi/(2*log10(coefzeros)) - pi/(2*log10(coefpoles)) );