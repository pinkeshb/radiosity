% Duarte Val�rio 2010

Ts = 0.01;
tfinal = 20;

slopedphase_10 = c2d(slopedphase3(1e-1, 1e1, 30, 11),0.01,'tustin'); temp = bode(slopedphase_10, 1); slopedphase_10 = slopedphase_10/temp;
slopedphase_20 = c2d(slopedphase3(1e-1, 1e1, 30, 22),0.01,'tustin'); temp = bode(slopedphase_20, 1); slopedphase_20 = slopedphase_20/temp;
slopedphase_30 = c2d(slopedphase3(1e-1, 1e1, 30, 33),0.01,'tustin'); temp = bode(slopedphase_30, 1); slopedphase_30 = slopedphase_30/temp;
slopedphase_40 = c2d(slopedphase3(1e-1, 1e1, 30, 44),0.01,'tustin'); temp = bode(slopedphase_40, 1); slopedphase_40 = slopedphase_40/temp;
slopedphase_50 = c2d(slopedphase3(1e-1, 1e1, 30, 55),0.01,'tustin'); temp = bode(slopedphase_50, 1); slopedphase_50 = slopedphase_50/temp;
slopedphase_60 = c2d(slopedphase3(1e-1, 1e1, 30, 66),0.01,'tustin'); temp = bode(slopedphase_60, 1); slopedphase_60 = slopedphase_60/temp;
slopedphase_70 = c2d(slopedphase3(1e-1, 1e1, 30, 77),0.01,'tustin'); temp = bode(slopedphase_70, 1); slopedphase_70 = slopedphase_70/temp;
slopedphase_80 = c2d(slopedphase3(1/8, 8, 30, 88),0.01,'tustin'); temp = bode(slopedphase_80, 1); slopedphase_80 = slopedphase_80/temp;
slopedphase_90 = c2d(slopedphase3(1/8, 8, 30, 100),0.01,'tustin'); temp = bode(slopedphase_90, 1); slopedphase_90 = slopedphase_90/temp;
slopedphase_100 = c2d(slopedphase3(1/7, 7, 30, 112),0.01,'tustin'); temp = bode(slopedphase_100, 1); slopedphase_100 = slopedphase_100/temp;
slopedphase__10 = tf(ss(1/slopedphase_10));
slopedphase__20 = tf(ss(1/slopedphase_20));
slopedphase__30 = tf(ss(1/slopedphase_30));
slopedphase__40 = tf(ss(1/slopedphase_40));
slopedphase__50 = tf(ss(1/slopedphase_50));
slopedphase__60 = tf(ss(1/slopedphase_60));
slopedphase__70 = tf(ss(1/slopedphase_70));
slopedphase__80 = tf(ss(1/slopedphase_80));
slopedphase__90 = tf(ss(1/slopedphase_90));
slopedphase__100 = tf(ss(1/slopedphase_100));

K_10 = [slopedphase_10.num{1} -slopedphase_10.den{1}(2:end)];
K_20 = [slopedphase_20.num{1} -slopedphase_20.den{1}(2:end)];
K_30 = [slopedphase_30.num{1} -slopedphase_30.den{1}(2:end)];
K_40 = [slopedphase_40.num{1} -slopedphase_40.den{1}(2:end)];
K_50 = [slopedphase_50.num{1} -slopedphase_50.den{1}(2:end)];
K_60 = [slopedphase_60.num{1} -slopedphase_60.den{1}(2:end)];
K_70 = [slopedphase_70.num{1} -slopedphase_70.den{1}(2:end)];
K_80 = [slopedphase_80.num{1} -slopedphase_80.den{1}(2:end)];
K_90 = [slopedphase_90.num{1} -slopedphase_90.den{1}(2:end)];
K_100 = [slopedphase_100.num{1} -slopedphase_100.den{1}(2:end)];
K__10 = [slopedphase__10.num{1} -slopedphase__10.den{1}(2:end)];
K__20 = [slopedphase__20.num{1} -slopedphase__20.den{1}(2:end)];
K__30 = [slopedphase__30.num{1} -slopedphase__30.den{1}(2:end)];
K__40 = [slopedphase__40.num{1} -slopedphase__40.den{1}(2:end)];
K__50 = [slopedphase__50.num{1} -slopedphase__50.den{1}(2:end)];
K__60 = [slopedphase__60.num{1} -slopedphase__60.den{1}(2:end)];
K__70 = [slopedphase__70.num{1} -slopedphase__70.den{1}(2:end)];
K__80 = [slopedphase__80.num{1} -slopedphase__80.den{1}(2:end)];
K__90 = [slopedphase__90.num{1} -slopedphase__90.den{1}(2:end)];
K__100 = [slopedphase__100.num{1} -slopedphase__100.den{1}(2:end)];
K_0 = zeros(size(K_10)); K0(1) = 1;