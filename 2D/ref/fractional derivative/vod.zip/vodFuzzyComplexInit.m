Ts = 0.01;
tfinal = 20;
n = 5;
wl = 1e-2;
wh = 1e2;
method = 'tustin';
clear j % make sure that j=sqrt(-1)

% Compare what follows with vodFuzzyInit.
% Since we have 121 functions this time, we don't want to make this by hand!
zstring = ''; pstring = ''; kstring = '';
alpha = [];
for a = -1 : 0.2 :1
    for b = -1 : 0.2 :1
        if a < 0, name = '_'; else name = ''; end
        name = [name sprintf('%02.0f', 10*abs(a))];
        if b < 0, name = [name '_']; end
        name = [name sprintf('%02.0f', 10*abs(b))];
        % discrete transfer functions
        eval(['G' name ' = c2d(croneFD(' sprintf('%+4.1f', a) sprintf('%+4.1f', b) 'j, wl, wh, n), Ts, method);'])
        % coefficients of the polynomials in the numerator and the denominator
        eval(['K' name ' = [G' name '.num{1} -G' name '.den{1}(2:end)];'])
        % zeros, poles and gains
        eval(['[z' name ', p' name ', k' name '] = zpkdata(G' name ');'])
        zstring = [zstring 'z' name '{1}, '];
        pstring = [pstring 'p' name '{1}, '];
        kstring = [kstring 'k' name ', '];
        alpha = [alpha; a+b*j];
    end
end
eval(['z = [' zstring(1:end-2) '].'';'])
z = sort(z,2); % for each approximation, zeros are sorted by magnitude
eval(['p = [' pstring(1:end-2) '].'';'])
p = sort(p,2); % for each approximation, poles are sorted by magnitude
eval(['k = [' kstring(1:end-2) '].'';'])
datazpk = [z, p, k];
datazpk = datazpk([1:11:end 2:11:end 3:11:end 4:11:end 5:11:end 6:11:end 7:11:end 8:11:end 9:11:end 10:11:end 11:11:end ],:); % reorder the lines
clear name zstring pstring kstring