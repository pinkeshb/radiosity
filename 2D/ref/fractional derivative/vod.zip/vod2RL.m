function out = vod2RL(t, in, alpha)
% function out = vod2RL(t, in, alpha)
% Variable order derivative, Riemann-Liouville definition, variant 2.
% Duarte Val�rio, 2009.

alphaINT = (real(alpha)>0) .* ceil(real(alpha)) + ...
    ( (real(alpha)==0) & (imag(alpha)~=0) ); % number of differentiations to perform
alphaRES = alpha - alphaINT; % residue of alphaINT with negative real part only

% negative differentiation (i.e. integration) performed
out = zeros(size(t));
for k = 1 : length(t)
    tau = t(1:k);
    integrand = (t(k) - tau).^(-alphaRES(1:k) - 1) ./ gamma(-alphaRES(1:k)) .* in(1:k);
    if any(~isfinite(integrand)) % eliminate eventual inf and nan points
        integrand(find(isinf(integrand))) = 0;
        integrand(find(isnan(integrand))) = 0;
    end
    integrand(1) = 2*integrand(1); % this is to handle steps properly with Caputo's definition
    % (otherwise the first point only has half the influence and the result comes halved all the way to the end)
    out(k) = sum( (integrand(1:end-1)+integrand(2:end))/2 .* (tau(2:end)-tau(1:end-1)) );
end

% necessary differentiations performed
while 1
    if sum(alphaINT) == 0, break, end % exit condition
    temp = diff([0; out]) ./ [t(2)-t(1); diff(t)]; % this is to handle steps properly
    out = out.*(alphaINT==0) + temp.*(alphaINT~=0);
    alphaINT = (alphaINT-1) .* (alphaINT~=0); % take away one integration
end