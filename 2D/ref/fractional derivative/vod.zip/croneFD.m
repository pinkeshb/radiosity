function G = croneFD(alpha, wl, wh, N)
% Crone approximation of s^alpha; alpha may be any complex number.
% N poles and N zeros are placed in [wl,wh] rad/s.

zeros = -wl * (wh/wl).^( (2*(1:N)-1-alpha) / (2*N) );
poles = -wl * (wh/wl).^( (2*(1:N)-1+alpha) / (2*N) );
G = tf(zpk(zeros, poles, 1));
if ~isreal(alpha)
    G = G * (j^alpha) / squeeze(freqresp(G, 1));
end