function [C, actualslope] = slopedphase2(wl, wh, N, slope)
% function [C, actualslope] = slopedphase2(wl, wh, N, slope)
% Finds a Crone approximation of a complex order derivative with a linear phase.
% C is the approximation, actualslope is the slope of the phase in degrees/decade.
% Zeros and poles are recursively placed in the [wl,wh] rad/s range.
% N is the desired number of poles (equal to the number of zeros).
% slope is the desired slope.
% It is not ensured that C will actually have N zeros and N poles,
% or that actualslope == slope.
% Zeros (for negative slopes) or poles (for positive slopes) will also be
% placed outside the [wl,wh] range to the extent needed to ensure a causal system.
% The phase of C will be 0 for w=1 rad/s.
% Duarte Val�rio 2010

recparams = fminsearch(@(recparams)aux(recparams,wl,wh,N,slope), [5 4]);
[C, actualslope] = slopedphase(wl, wh, recparams(1), recparams(2));

function out = aux(recparams, wl, wh, N, slope)
[C, actualslope] = slopedphase(wl, wh, recparams(1), recparams(2));
actualN = length(pole(C))+length(zero(C));
out = (actualslope-slope)^2 + ((actualN-N)*20)^2;