function [C, actualslope] = slopedphase3(wl, wh, product, slope)
% function [C, actualslope] = slopedphase3(wl, wh, product, slope)
% Finds a Crone approximation of a complex order derivative with a linear phase.
% C is the approximation, actualslope is the slope of the phase in degrees/decade.
% Zeros and poles are recursively placed in the [wl,wh] rad/s range.
% product is the product of the recursivity coefficients.
% slope is the desired slope. It is not ensured that actualslope == slope.
% Zeros (for negative slopes) or poles (for positive slopes) will also be
% placed outside the [wl,wh] range to the extent needed to ensure a causal system.
% The phase of C will be 0 for w=1 rad/s.
% Duarte Val�rio 2010

recparams = fminsearch(@(recparams)aux(recparams,wl,wh,product,slope), 5);
[C, actualslope] = slopedphase(wl, wh, recparams, product/recparams);

function out = aux(recparams, wl, wh, product, slope)
[C, actualslope] = slopedphase(wl, wh, recparams, product/recparams);
out = (actualslope-slope)^2;