function out = vod2GL(t, in, alpha)
% function out = vod2GL(t, in, alpha)
% Variable order derivative, Gr�nwald-Letnikoff definition, variant 2.
% Duarte Val�rio, 2009.

Ts = diff(t);
if max(Ts) - min(Ts) > 1e-10 * mean(Ts) % Values in t must be in linear progression.
    error('Time samples must be evenly spaced.');
else
    Ts = mean(Ts);
end

% determine the first value n for which gamma(n)==inf; we'll assume gamma(70) is feasible in all machines
MAX = 70;
while 1
    if isinf(gamma(MAX)), break, end
    MAX = MAX+1;
end
MAX = 2*floor( (MAX-2)/2 ); % gamma(MAX) must still be finite; MAX must be even

out = zeros(size(t));
for i = 1 : length(t) % we will sweep the time instants
    k = round(0 : min([i-1, MAX]))'; % notice that t(i)/Ts == i-1; round is a precaution against numerical errors
    vector = ( (-1).^k .* in(i-k) .* gamma(alpha(i-k)+1) ) ./...
        ( gamma(k+1) .* gamma(alpha(i-k)-k+1) ) ./ Ts.^alpha(i-k);
    vector(find(isnan(vector))) = 0; % take away NaNs
    out(i) = sum( vector );
    % if we were unable to take k up to t(i)/Ts, because function gamma would return inf, we'll try to make up for
    % that decimating the sampling time
    factorTs = 1; % this factor will be equal to 1, 2, 4, 8 ... 2^n ... and will affect the sampling time
    while 1
        if t(i)/(factorTs*Ts) <= MAX, break, end
        factorTs = factorTs * 2;
        k = round(MAX/2+1 : min([t(i)/(factorTs*Ts), MAX]))'; % compare with the vector above
        vector = ( (-1).^k .* in(i-factorTs*k) .* gamma(alpha(i-factorTs*k)+1) ) ./...
            ( gamma(k+1) .* gamma(alpha(i-factorTs*k)-k+1) ) ./ (factorTs*Ts).^alpha(i-factorTs*k);
        vector(find(isnan(vector))) = 0; % take away NaNs
        out(i) = out(i) + sum( vector );
    end
    %... but as consequence of increasing the sampling time, when this make-up loop is resorted to,
    % the response will remain constant during a few sampling times, as many as factorTs (that's the price to pay)
end