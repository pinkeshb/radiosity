function out = findfreqresp(in)

Ts = real( in(1) );
num = in(2:7);
den = in(8:end);
G = tf(num, den, Ts);
out = squeeze( freqresp(G, 1) );