// WinOSIDoc.h : interface of the CWinOSIDoc class
//
/////////////////////////////////////////////////////////////////////////////

#include "VModelFile.h"

class CWinOSIDoc : public CDocument
{
protected: // create from serialization only
	CWinOSIDoc();
	DECLARE_DYNCREATE(CWinOSIDoc)

// Attributes
public:
  VModelFile   VMF;
  BSPplane    *BSPtree;
  PrLP         Invisibles;

// Operations

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWinOSIDoc)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CWinOSIDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CWinOSIDoc)
	afx_msg void OnFileOpen();
	afx_msg void OnFileSaveImg();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

extern OPENFILENAME   OFName;
extern CWinOSIDoc    *Document;