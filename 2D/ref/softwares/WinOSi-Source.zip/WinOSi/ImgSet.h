// ImgSet.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// ImgSet dialog

class ImgSet : public CDialog
{
// Construction
public:
	ImgSet(CWnd* pParent = NULL);   // standard constructor
	float  OldRE;
	double OldGm;

// Dialog Data
	//{{AFX_DATA(ImgSet)
	enum { IDD = IDD_SETTINGS };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(ImgSet)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(ImgSet)
	afx_msg void OnClose();
	afx_msg void OnOk();
	virtual BOOL OnInitDialog();
	afx_msg void OnPreview();
	afx_msg void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

extern ImgSet* imageSettings;

