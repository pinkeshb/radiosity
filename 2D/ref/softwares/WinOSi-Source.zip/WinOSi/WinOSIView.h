// WinOSIView.h : interface of the CWinOSIView class
//
/////////////////////////////////////////////////////////////////////////////

class CWinOSIView : public CView
{
protected: // create from serialization only
	CWinOSIView();
	DECLARE_DYNCREATE(CWinOSIView)

// Attributes
public:
  CWinOSIDoc* GetDocument();
  HBITMAP     bmp;
  CPalette    MyPalette;
  BOOL        use_palette;
  BITMAPINFO  BMPinfo;
  byte       *BMPbits;

// Operations
public:
  void DrawDIB_Init();
  void MakeDDB(HBITMAP ddb, CDC *hdc, BITMAPINFO *BMPinfo, byte *BMPbits);
  void MakeDDBLine(int y, HBITMAP ddb, CDC *hdc, BITMAPINFO *BMPinfo, byte *BMPbits);
  void InitViewPort(int XRES, int YRES); 

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWinOSIView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CWinOSIView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CWinOSIView)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	afx_msg void OnImageCopy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in WinOSIView.cpp
inline CWinOSIDoc* CWinOSIView::GetDocument()
   { return (CWinOSIDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

extern CWinOSIView *ViewPort;
