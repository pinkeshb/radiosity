//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by WinOSI.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_WINOSITYPE                  129
#define IDD_SETTINGS                    130
#define IDD_Render                      132
#define IDD_Info                        133
#define IDC_ExpAbs                      1008
#define IDC_ExpRel                      1009
#define IDC_Gamma                       1010
#define IDC_GammaScroll                 1011
#define IDC_Preview                     1012
#define IDC_OK                          1013
#define IDC_Cancel                      1014
#define IDC_EDIT_XRes                   1015
#define IDC_EDIT_YRes                   1016
#define IDC_EDIT_HB                     1017
#define IDC_Raytrace                    1018
#define IDC_Direct                      1019
#define IDC_Rays                        1019
#define IDC_2Pass                       1020
#define IDC_Hits                        1020
#define IDC_EDIT_SpecDepth              1021
#define IDC_HpR                         1021
#define IDC_EDIT_SpecLightDepth         1021
#define IDC_EDIT_DiffDepth              1022
#define IDC_ToTime                      1022
#define IDC_EDIT_DiffShots              1023
#define IDC_ThTime                      1023
#define IDC_EDIT_SpecViewDepth          1023
#define IDC_EDIT_PRadius                1024
#define IDC_Rps                         1024
#define IDC_Hps                         1025
#define IDC_StS_Lighting                1025
#define IDC_MScene                      1026
#define IDC_StS_Diffuse                 1026
#define IDC_MBuffers                    1027
#define IDC_StS_SkyDome                 1027
#define IDC_MOctree                     1028
#define IDC_MMaps                       1029
#define IDC_MTotal                      1030
#define IDC_SObj                        1031
#define IDC_EIn                         1032
#define IDC_EOut                        1033
#define IDC_ENy                         1034
#define IDC_Runs                        1035
#define IDC_SMat                        1036
#define IDC_SLit                        1037
#define IDC_Cntr                        1038
#define IDC_Diff                        1039
#define ID_RENDER_STARTRENDERING        32772
#define ID_RENDER_STOPRENDERING         32773
#define ID_IMAGE_SETTINGS               32774
#define ID_IMAGE_COPY                   32775
#define ID_RENDER_SETTINGS              32776
#define ID_RENDER_CONTINUE              32777
#define ID_SAVE_PROJECT                 32778
#define ID_OPEN_PROJECT                 32779
#define ID_FILE_INFO                    32780
#define ID_MERGE_PROJECT                32781
#define ID_FILE_SAVE_IMG                57605

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32782
#define _APS_NEXT_CONTROL_VALUE         1028
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
