// WinOSI.h : main header file for the WINOSI application
//

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#define Pi_2    1.5707963

#define fTwoPi  6.2831853f
#define fPi     3.1415927f
#define fPi_2   1.5707963f

/////////////////////////////////////////////////////////////////////////////
// CWinOSIApp:
// See WinOSI.cpp for the implementation of this class
//

class CWinOSIApp : public CWinApp
{
public:
	CWinOSIApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWinOSIApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CWinOSIApp)
	afx_msg void OnAppAbout();
	afx_msg void OnRenderStart();
	afx_msg void OnRenderStop();
	afx_msg void OnRenderContinue();
	afx_msg void OnSaveProject();
	afx_msg void OnOpenProject();
	afx_msg void OnImageSettings();
	afx_msg void OnRenderSettings();
	afx_msg void OnFileInfo();
	afx_msg void OnUpdateRenderStop(CCmdUI* pCmdUI);
	afx_msg void OnUpdateAppExit(CCmdUI* pCmdUI);
	afx_msg void OnUpdateOpenProject(CCmdUI* pCmdUI);
	afx_msg void OnUpdateRenderContinue(CCmdUI* pCmdUI);
	afx_msg void OnUpdateRenderStart(CCmdUI* pCmdUI);
	afx_msg void OnUpdateSaveProject(CCmdUI* pCmdUI);
	afx_msg void OnUpdateFileOpen(CCmdUI* pCmdUI);
	afx_msg void OnUpdateRenderSettings(CCmdUI* pCmdUI);
	afx_msg void OnMergeProject();
	afx_msg void OnUpdateMergeProject(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

class RGB_Dbl
{
  public:
    double R,G,B;
    RGB_Dbl(){}
    RGB_Dbl(double red, double green, double blue) { R=red; G=green; B=blue; }
    void       operator += (const RGB_Color & c)
      { R+=(double)c.R; G+=(double)c.G; B+=(double)c.B; }
};

typedef struct HitPoint *HtPPtr;


struct HitPoint {
  HtPPtr  next;
  RV_PrP  obj;
  vector  pos;
  vector  N;
  float   val;
  short   side;
};


extern int       HitBuffers;
extern int       DiffDepth;
extern int       SpecLightDepth;
extern int       SpecViewDepth;
extern int       Renderer;

extern float     pixelsize;
extern float     wavlen;

extern float     RelExp;
extern double    Gamma;

extern void      WaitTask();
extern void      RenderImg();
extern RGB_Color WL2RGB(float v);

