// WinOSI.cpp : Defines the class behaviors for the application.
//

#include <stdlib.h>
#include <time.h>

#include "stdafx.h"
#include "general.h"
#include "Primitives.h"
#include "RaVi.h"
#include "resource.h"
#include "WinOSI.h"
#include "OCTree.h"

#include "ImgSet.h"
#include "PInfo.h"
#include "RendSet.h"
#include "MainFrm.h"

#include "WinOSIDoc.h"
#include "WinOSIView.h"

#ifdef _DEBUG
  #define new DEBUG_NEW
  #undef THIS_FILE
  static char THIS_FILE[] = __FILE__;
#endif

#define HBSize 1000

typedef struct Lite  *LitePtr;

struct Lite {
  LitePtr nxt;
  RV_PrP  obj;
  float   pti;
  float   lar;
};

int       XRes = 320;
int       YRes = 240;

short     Demo;
QLst      QLT[16];

float     pixelsize;
float     wavlen;

float     RelExp = 0.15f;
double    Gamma  = 1.40f;

int       HitBuffers     = 200;
int       DiffDepth      =   2;
int       SpecLightDepth =   4;
int       SpecViewDepth  =   4;
int       StS_Light      =   1;
int       StS_Diff       =   1;
int       StS_Sky        =   1;
float     GlobalIOR      = 1.0f;
float     PixelRadius    = 1.4142f;

RGB_Dbl   *accu = NULL; // accumulation buffer
RGB_Color *rend = NULL; // render buffer

RGB_Color Tint;         // Lighting Color Tint

OCTree    SHTree;       // Main Scene and HitBuffer Oct-tree

LitePtr   LiteRoot=NULL;

HtPPtr   *HBuffer=NULL;
int       HBi,HBp;

matrix    E;

double    dc,dfc;
double    fc = 3.0e10;

extern   long int  sSLit;
extern   vector   *RV_CamPtr;

int RV_Caustics_Samples=10000;
int RV_Caustics_Quality=   30;

__int64  sRays=0,sHits=0;

unsigned long int  sRuns,Hits,nn,Passes=0;
unsigned long int  pRays,pHits;
unsigned long int  sMBa=0,sMBr=0,sMGl;
unsigned long int  sMTh=0,sMTo=0;
double             sOut=0.0,pIn,sIn=0.0;
double             sCtr,sDif;

time_t    sRTime;
time_t    RTCurr;
time_t    TStart;

BOOL      Stop = TRUE;
BOOL      Exit = FALSE;
CDC      *glhdc;

Thrdata   ThD;

float wlcoff(float cR, float cG, float cB, float v);

RGB_Color WL2RGB(float v)
{
  RGB_Color Color;
  Color.R = wlcoff(0.68292f, 0.0f, 0.0f, v);
  Color.G = wlcoff(0.0f, 1.00000f, 0.0f, v);
  Color.B = wlcoff(0.0f, 0.0f, 1.16667f, v);
  return Color;
}


void DrawSB(int y, COLORREF c)
{
  CDC  *hdc;

  hdc = ViewPort->GetDC(); if(ViewPort->use_palette) hdc->SelectPalette(&(ViewPort->MyPalette), FALSE);
  hdc->FillSolidRect(XRes, YRes,9,-y,c);
  ViewPort->ReleaseDC(hdc);
}


float R_fnf(float n1, float n2, double ce1);

RGB_Color PutPhoton(RV_PrP OrgObj, MatPtr mat, vector *Org, vector *Ray, IntPar IntP, float em, float dist, int level, Thrdata *Thread)
{
  GetIPN(Org, Ray, &IntP); float ca = IntP.N % *Ray;
  MatPtr m = IntP.p->Mat; if(m->Texture) GetTXY(&IntP);
  if((HBi>=HitBuffers) || (em<=0.001f)) return RGB_Color(0.0f, 0.0f, 0.0f);
  if(level==0) pHits++;
  float v1 = em * mat->Thru(wavlen,(float)distance(*Org, IntP.IP)); float md = m->Diff(wavlen, IntP.x, IntP.y); float val = v1 * md;
  // phong interpolation
  if(IntP.p->type < 2){
    if(((RV_TriPara *)(IntP.p))->sinfo && ((RV_TriPara *)(IntP.p))->sinfo->nrm){
      vector Np = ((RV_TriPara *)(IntP.p))->N; float cp = Np % *Ray;
	  val=val*ca/cp;
	}
  }
  if(val>0.0f) {
    HtPPtr hp = HBuffer[HBi]+HBp; HBp++; if(HBp>=HBSize){ DrawSB(YRes*HBi/HitBuffers,0x0000F0); WaitTask(NULL); HBi++; HBp=0; }
	hp->next  = NULL;
	hp->obj   = IntP.p;
	hp->pos   = IntP.IP;
	hp->N     = (ca)>0.0? -IntP.N : IntP.N;
	hp->side  = (ca)>0.0?       0 :      1;
	hp->val   = val;
	SHTree.PutIn(hp);
  }
  // distribute diffuse reflected light
  if((float)rnd() < md){
    vector OutDir=crndhdir(IntP.N);
    RayTrace(Thread, IntP.p, NULL, mat, &(IntP.IP), &OutDir, v1 , 0.0f, &PutPhoton, level+1, DiffDepth);
  }

  // specular reflection/refraction
  if((level<SpecLightDepth) && (m->Specularity>ray_thresh)){
    float  spc = 0.0f, trn=0.0f;
	//float  ca  = IntP.N % *Ray;
	vector OutDir;

	if(m->Transmission.R < 0.0f){
	  // fresnel reflection?
	  float n1,n2;
  	  if(ca<0.0f){
	    n1=mat->IOR(wavlen); n2=            m->IOR(wavlen);
	  } else {
        n1=m  ->IOR(wavlen); n2=RV_Environment.IOR(wavlen);
	  }
	  spc = m->Specularity * R_fnf(n1,n2,ca); trn = m->Specularity-spc;
	} else {
	  // simple specular reflection/refraction?
	  if((m->Specularity > ray_thresh) && (m->type!=Shader_Phong)){
	    spc = m->Specularity * ((m->Reflection.G < 0.0f)? m->Reflection.R : wlcoff(m->Reflection.R, m->Reflection.G, m->Reflection.B, wavlen));
        trn = m->Transmission.R;
	  }
	}

	// distribute specular reflected light
	if((float)rnd() < spc) {
	  // mirror direction
	  OutDir = -unit(2.0f * ca * IntP.N - *Ray); if(m->PBExp > 0.001f) OutDir = rndpdir(OutDir, 1.0f/m->PBExp);
	  RayTrace(Thread, IntP.p, NULL, &RV_Environment, &(IntP.IP), &OutDir, v1, 0.0f, &PutPhoton, level+1, SpecLightDepth);
	}
    // distribute transmitted (refracted) light
	if((float)rnd() < trn) {
	  if(ca<0.0f){
	    OutDir=refract(*Ray,  IntP.N, mat->IOR(wavlen),             m->IOR(wavlen));
	    RayTrace(Thread, IntP.p, NULL,                           m                    , &(IntP.IP), &OutDir, v1, 0.0f, &PutPhoton, level+1, SpecLightDepth);
	  } else {
	    OutDir=refract(*Ray, -IntP.N, mat->IOR(wavlen), RV_Environment.IOR(wavlen));
	    RayTrace(Thread, IntP.p, NULL, ((OutDir % IntP.N)<0.0f)? m : &(RV_Environment), &(IntP.IP), &OutDir, v1, 0.0f, &PutPhoton, level+1, SpecLightDepth);
	  }
	}
  }
  
  return RGB_Color(0.0f, 0.0f, 0.0f);
}


RGB_Color GetDiffuse(RV_PrP OrgObj, MatPtr mat, vector *Org, vector *Ray, IntPar IntP, float em, float dist, int level, Thrdata *Thread)
{
  GetIPN(Org, Ray, &IntP);
  RGB_Color col; float ca = IntP.N % *Ray; float dt=(float)distance(*Org, IntP.IP); MatPtr m = IntP.p->Mat;
  col.R = SHTree.GetVal(IntP.IP, *Ray, (dist+dt)*pixelsize, ca>0.0f?  0 : 1, OrgObj);

  if(m->Emission.R>0.001f){
    LitePtr l=LiteRoot; while(l && (l->obj != IntP.p)) l=l->nxt;
	col.R += pRays*m->Emission.R/l->lar;
  }

  // specular reflection/refraction
  if((level<SpecViewDepth) && (m->Specularity>ray_thresh)){
    float  spc = 0.0f, trn=0.0f;
	vector OutDir;

	if(m->Transmission.R < 0.0f){
	  // fresnel reflection?
	  float n1,n2;
  	  if(ca<0.0f){
	    n1=mat->IOR(wavlen); n2=            m->IOR(wavlen);
	  } else {
        n1=m  ->IOR(wavlen); n2=RV_Environment.IOR(wavlen);
	  }
	  spc = m->Specularity * R_fnf(n1,n2,ca); trn = m->Specularity-spc;
	} else {
	  // simple specular reflection/refraction?
	  if((m->Specularity > ray_thresh) && (m->type!=Shader_Phong)){
	    spc = m->Specularity * ((m->Reflection.G < 0.0f)? m->Reflection.R : wlcoff(m->Reflection.R, m->Reflection.G, m->Reflection.B, wavlen));
        trn = m->Transmission.R;
	  }
	}

	// collect specular reflected light
	if(spc > ray_thresh) {
	  // mirror direction
	  OutDir = -unit(2.0f * ca * IntP.N - *Ray); if(m->PBExp > 0.001f) OutDir = rndpdir(OutDir, 1.0f/m->PBExp);
	  col += spc * RayTrace(Thread, IntP.p, NULL, &RV_Environment, &(IntP.IP), &OutDir, 1.0f, dist+dt, &GetDiffuse, level+1, SpecViewDepth);
	}
    // collect transmitted (refracted) light
	if(trn > ray_thresh) {
	  if(ca<0.0f){
	    OutDir=refract(*Ray,  IntP.N, mat->IOR(wavlen),             m->IOR(wavlen));
	    col += trn * RayTrace(Thread, IntP.p, NULL,                           m                    , &(IntP.IP), &OutDir, 1.0f, dist+dt, &GetDiffuse, level+1, SpecViewDepth);
	  } else {
	    OutDir=refract(*Ray, -IntP.N, mat->IOR(wavlen), RV_Environment.IOR(wavlen));
	    col += trn * RayTrace(Thread, IntP.p, NULL, ((OutDir % IntP.N)<0.0f)? m : &(RV_Environment), &(IntP.IP), &OutDir, 1.0f, dist+dt, &GetDiffuse, level+1, SpecViewDepth);
	  }
	}
  }
  // absorbtion
  col *= mat->Thru(wavlen, dt); 
  return col;
}

RGB_Color CallGetDiffuse(vector *Org, vector *Ray, IntPar IntP, MatPtr mat, int level)
{
  return GetDiffuse(NULL, mat, Org, Ray, IntP, 1.0f, 0.0f, level, &ThD);
}

void RenderImg()
{
  byte     *bitptr;
  RGB_Dbl  *acuptr;
  CDC      *hdc;
  CDC       mem;
  double    sCto,smf=0.0;
  int       x,y;
  RGB_Color Col;
  RGB_Color Bal; float Avg;

  if(accu){
	// calculate white balance
	if(Tint.R && Tint.G && Tint.B){
      Avg=(Tint.R + Tint.G + Tint.B)/3.0f;
	  Bal.R = Avg/Tint.R;
	  Bal.G = Avg/Tint.G;
	  Bal.B = Avg/Tint.B;
	} else {
	  Bal = RGB_Color(1.0f, 1.0f, 1.0f);
	}
	// calculate exposure
    for(y=0; y<YRes; y++){
      acuptr=accu+(y*XRes);
      for(x=0;x<XRes;x++) smf+=(0.3*acuptr[x].R + 0.59*acuptr[x].G + 0.11*acuptr[x].B);
	} fc=RelExp*(double)(XRes*YRes)/smf; sCto=sCtr; sCtr=0.0;
    // render buffer to bitmap
    for(y=0; y<YRes; y++){
      bitptr=(ViewPort->BMPbits)+(y*((XRes*3+3) & 0xFFFFFFFC));
      acuptr=accu+(y*XRes);
      for(x=0;x<XRes;x++){
        Col.R = (float)pow(acuptr[x].R*fc*Bal.R, 1.0/Gamma);
        Col.G = (float)pow(acuptr[x].G*fc*Bal.G, 1.0/Gamma);
        Col.B = (float)pow(acuptr[x].B*fc*Bal.B, 1.0/Gamma);
  	    bitptr[3*x  ]=(byte)((255.0f*Col.B)>255.0f? 255 : 255.0f*Col.B);
  	    bitptr[3*x+1]=(byte)((255.0f*Col.G)>255.0f? 255 : 255.0f*Col.G);
  	    bitptr[3*x+2]=(byte)((255.0f*Col.R)>255.0f? 255 : 255.0f*Col.R);
	  }
	}
    // calculate contrast
    for(y=1; y<(YRes-1); y++){
      acuptr=accu+(y*XRes);
      for(x=1;x<(XRes-1);x++){
        sCtr += fabs(acuptr[x].G -  acuptr      [x+1].G);
        sCtr += fabs(acuptr[x].G -  acuptr      [x-1].G);
        sCtr += fabs(acuptr[x].G - (acuptr-XRes)[x  ].G);
        sCtr += fabs(acuptr[x].G - (acuptr+XRes)[x  ].G);
	  }
	} sCtr /= smf; sDif=sCto-sCtr;
    // blit bitmap to screen
    hdc = ViewPort->GetDC(); if(ViewPort->use_palette) hdc->SelectPalette(&(ViewPort->MyPalette), FALSE);
    mem.CreateCompatibleDC(hdc); mem.SelectObject(ViewPort->bmp);
    ViewPort->MakeDDB(ViewPort->bmp, hdc, &(ViewPort->BMPinfo), ViewPort->BMPbits);
    hdc->BitBlt(0, 0, ViewPort->BMPinfo.bmiHeader.biWidth, ViewPort->BMPinfo.bmiHeader.biHeight,&mem, 0, 0, SRCCOPY);
    mem.DeleteDC(); ViewPort->ReleaseDC(hdc); WaitTask(NULL);
  }
}

void ChgRes(int nXRes, int nYRes)
{
  if((nXRes!=XRes) || (nYRes!=YRes)){
    XRes=nXRes; YRes=nYRes;
    ViewPort->InitViewPort(XRes, YRes);
    int cx = XRes+2*GetSystemMetrics(SM_CXSIZEFRAME)+4+20;
    int cy = YRes+2*GetSystemMetrics(SM_CYSIZEFRAME)+GetSystemMetrics(SM_CYCAPTION)+GetSystemMetrics(SM_CYMENU)+22;
	CRect win;MFrame->GetWindowRect(&win);
    MFrame->MoveWindow(win.left, win.top, cx, cy, TRUE);
  }
}

void SaveProject(char *filename) 
{
  FILE     *OSIfile;
  RGB_Dbl  *acuptr;
  RGB_Color TempCol;
  int       x,y,Ver=4;
  float     AbsExp = 0.0f;
  float     fGamma = (float)Gamma;
  time_t    iTime  = sRTime+=RTCurr;
  OSIfile = fopen(filename,"w+b");
  if(OSIfile){
    fwrite(&Ver,      sizeof(int              ),1, OSIfile);
    fwrite(&XRes,     sizeof(int              ),1, OSIfile);
    fwrite(&YRes,     sizeof(int              ),1, OSIfile);
    fwrite(&AbsExp,   sizeof(float            ),1, OSIfile);
    fwrite(&RelExp,   sizeof(float            ),1, OSIfile);
    fwrite(&fGamma,   sizeof(float            ),1, OSIfile);
    fwrite(&(Tint.R), sizeof(float            ),1, OSIfile);
    fwrite(&(Tint.G), sizeof(float            ),1, OSIfile);
    fwrite(&(Tint.B), sizeof(float            ),1, OSIfile);
    fwrite(&sRays,    sizeof(unsigned long int),1, OSIfile);
    fwrite(&sHits,    sizeof(unsigned long int),1, OSIfile);
    fwrite(&sIn,      sizeof(double           ),1, OSIfile);
    fwrite(&iTime,    sizeof(time_t           ),1, OSIfile);
    for(y=0; y<YRes; y++){
      acuptr=accu+(y*XRes);
	  for(x=0; x<XRes; x++){
	    TempCol.R = (float)(acuptr[x].R);
		TempCol.G = (float)(acuptr[x].G);
		TempCol.B = (float)(acuptr[x].B);
        fwrite(&TempCol, sizeof(RGB_Color), 1, OSIfile);
	  }
	}
    fclose(OSIfile);
  } else ViewPort->MessageBox("Datei konnte nicht ge�ffnet werden.","Fehler",MB_ICONSTOP | MB_OK);
}

void OpenProject(char *filename) 
{
  FILE     *OSIfile;
  RGB_Dbl  *acuptr;
  RGB_Color TempCol;
  int       x,y,Ver;
  float     AbsExp;
  float     fGamma;
  long int  NH;

  OSIfile = fopen(filename,"r+b");
  if(OSIfile){
      int nXRes, nYRes;
      fread(&Ver, sizeof(int),1, OSIfile);
	  if(Ver==2){
        fread(&nXRes, sizeof(int     ),1, OSIfile);
        fread(&nYRes, sizeof(int     ),1, OSIfile);
        fread(&RelExp,sizeof(float   ),1, OSIfile);
        fread(&Gamma, sizeof(double  ),1, OSIfile);
        fread(&NH,    sizeof(long int),1, OSIfile); nn=NH/HitBuffers;
      } else { // Ver==3:
        fread(&nXRes, sizeof(int              ),1, OSIfile);
        fread(&nYRes, sizeof(int              ),1, OSIfile);
        fread(&AbsExp,sizeof(float            ),1, OSIfile);
        fread(&RelExp,sizeof(float            ),1, OSIfile);
        fread(&fGamma,sizeof(float            ),1, OSIfile); Gamma=fGamma;
	    if(Ver==4){
          fread(&(Tint.R),sizeof(float        ),1, OSIfile);
          fread(&(Tint.G),sizeof(float        ),1, OSIfile);
          fread(&(Tint.B),sizeof(float        ),1, OSIfile);
		} else Tint=RGB_Color(10000.0f, 10000.0f, 10000.0f);
        fread(&sRays, sizeof(unsigned long int),1, OSIfile);
        fread(&sHits, sizeof(unsigned long int),1, OSIfile); nn=0;
        fread(&sIn,   sizeof(double           ),1, OSIfile);
        fread(&sRTime,sizeof(time_t           ),1, OSIfile);
	  }
      accu=new(RGB_Dbl[nXRes*nYRes]); sMBa=nXRes*nYRes*sizeof(RGB_Dbl);
	  for(y=0; y<nYRes; y++){
        acuptr=accu+(y*nXRes);
		for(x=0; x<nXRes; x++){
          fread(&TempCol, sizeof(RGB_Color), 1, OSIfile);
		  acuptr[x].R = TempCol.R;
		  acuptr[x].G = TempCol.G;
		  acuptr[x].B = TempCol.B;
		}
	  }
	  ChgRes(nXRes, nYRes);
      fclose(OSIfile);
      RenderImg(); if(projectInfo) projectInfo->Update();
  }// else ViewPort->MessageBox("Datei konnte nicht ge�ffnet werden.","Fehler",MB_ICONSTOP | MB_OK);
}

void MergeProject(char *filename) 
{
  FILE     *OSIfile;
  RGB_Dbl  *acuptr;
  RGB_Color TempCol;
  RGB_Color nTint;
  int       x,y,Ver;
  float     AbsExp,nRelExp;
  float     fGamma;
  long int  NH,nsRays,nsHits;
  double    nsIn;
  time_t    nsRTime;

  OSIfile = fopen(filename,"r+b");
  if(OSIfile){
      int nXRes, nYRes;
      fread(&Ver, sizeof(int),1, OSIfile);
	  if(Ver==2){
		double nGamma;
        fread(&nXRes,  sizeof(int     ),1, OSIfile);
        fread(&nYRes,  sizeof(int     ),1, OSIfile);
        fread(&nRelExp,sizeof(float   ),1, OSIfile);
        fread(&nGamma, sizeof(double  ),1, OSIfile); fGamma=(float)nGamma;
        fread(&NH,     sizeof(long int),1, OSIfile); nn=NH/HitBuffers;
      } else { // Ver==3:
        fread(&nXRes,  sizeof(int              ),1, OSIfile);
        fread(&nYRes,  sizeof(int              ),1, OSIfile);
        fread(&AbsExp, sizeof(float            ),1, OSIfile);
        fread(&nRelExp,sizeof(float            ),1, OSIfile);
        fread(&fGamma, sizeof(float            ),1, OSIfile);
	    if(Ver==4){
          fread(&(nTint.R),sizeof(float        ),1, OSIfile);
          fread(&(nTint.G),sizeof(float        ),1, OSIfile);
          fread(&(nTint.B),sizeof(float        ),1, OSIfile);
		} else nTint=RGB_Color(10000.0f, 10000.0f, 10000.0f);
        fread(&nsRays, sizeof(unsigned long int),1, OSIfile);
        fread(&nsHits, sizeof(unsigned long int),1, OSIfile); nn=0;
        fread(&nsIn,   sizeof(double           ),1, OSIfile);
        fread(&nsRTime,sizeof(time_t           ),1, OSIfile);
	  }
      if((nXRes==XRes) && (nYRes==YRes)){
	    for(y=0; y<nYRes; y++){
          acuptr=accu+(y*nXRes);
		  for(x=0; x<nXRes; x++){
            fread(&TempCol, sizeof(RGB_Color), 1, OSIfile);
		    acuptr[x].R += TempCol.R;
		    acuptr[x].G += TempCol.G;
		    acuptr[x].B += TempCol.B;
		  }
		}
	    Gamma   = 0.5 *(Gamma +fGamma );
		RelExp  = 0.5f*(RelExp+nRelExp);
		Tint    = 0.5f*(Tint  +nTint  );
		sRays  += nsRays;
		sHits  += nsHits;
		sIn    += nsIn;
		sRTime += nsRTime;
	  } else {
		MessageBox(NULL,"resolutions don't match!","Error",MB_ICONSTOP | MB_OK);
	  }
      fclose(OSIfile);
      RenderImg(); if(projectInfo) projectInfo->Update();
  }// else ViewPort->MessageBox("Datei konnte nicht ge�ffnet werden.","Fehler",MB_ICONSTOP | MB_OK);
}

float CalcArea(RV_PrP p){
  if(p->type == 0){
	return Betrag(((RV_TriPara *)p)->edg1 * ((RV_TriPara *)p)->edg2 * 0.5f);
  } else if(p->type == 1){
	return Betrag(((RV_TriPara *)p)->edg1 * ((RV_TriPara *)p)->edg2       );
  } else if(p->type == 2){
    return ((RV_SimpleSphere *)p)->r2*4*Pi;
  }
  return 1.0f;
}

// calculate total global light emission of tree content
float CalcGLE(BSPplane *tree)
{
  if(tree->axis == 0){
    float LLE=0.0f; PrLP p = (PrLP)tree->left;
    while(p){
	  if(p->Prim->Mat->Emission.R > 0.0f){
	    if(p->Prim->lastframe != 111){
		  LLE += p->Prim->Mat->Emission.R; sSLit++;
		  p->Prim->lastframe=111;
		}
	  }
      p=p->next;
	}
	return LLE;
  } else {
	return CalcGLE(tree->left) + CalcGLE(tree->rigt);
  }
}

// create light-emitter-list with statistically distibuted priorities
void CreateLL(BSPplane *tree, float & cpti, float GLI)
{
  if(tree->axis == 0){
    PrLP p = (PrLP)tree->left;
    while(p){
	  if(p->Prim->Mat->Emission.R > 0.0f){
	    if(p->Prim->lastframe != 112){
          LitePtr l      = new(Lite);
	              l->nxt = LiteRoot; LiteRoot=l;
	              l->obj = p->Prim;
	              l->pti = cpti; cpti -= p->Prim->Mat->Emission.R / GLI;
				  l->lar = CalcArea(p->Prim);
		  p->Prim->lastframe=112;
		}
	  }
      p=p->next;
	}
  } else {
	CreateLL(tree->left, cpti, GLI);
	CreateLL(tree->rigt, cpti, GLI);
  }
}

/////////////////////////////////////////////////////////////////////////////
// CWinOSIApp

BEGIN_MESSAGE_MAP(CWinOSIApp, CWinApp)
	//{{AFX_MSG_MAP(CWinOSIApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	ON_COMMAND(ID_RENDER_STARTRENDERING, OnRenderStart)
	ON_COMMAND(ID_RENDER_STOPRENDERING, OnRenderStop)
	ON_COMMAND(ID_RENDER_CONTINUE, OnRenderContinue)
	ON_COMMAND(ID_SAVE_PROJECT, OnSaveProject)
	ON_COMMAND(ID_OPEN_PROJECT, OnOpenProject)
	ON_COMMAND(ID_IMAGE_SETTINGS, OnImageSettings)
	ON_COMMAND(ID_RENDER_SETTINGS, OnRenderSettings)
	ON_COMMAND(ID_FILE_INFO, OnFileInfo)
	ON_UPDATE_COMMAND_UI(ID_RENDER_STOPRENDERING, OnUpdateRenderStop)
	ON_UPDATE_COMMAND_UI(ID_APP_EXIT, OnUpdateAppExit)
	ON_UPDATE_COMMAND_UI(ID_OPEN_PROJECT, OnUpdateOpenProject)
	ON_UPDATE_COMMAND_UI(ID_RENDER_CONTINUE, OnUpdateRenderContinue)
	ON_UPDATE_COMMAND_UI(ID_RENDER_STARTRENDERING, OnUpdateRenderStart)
	ON_UPDATE_COMMAND_UI(ID_SAVE_PROJECT, OnUpdateSaveProject)
	ON_UPDATE_COMMAND_UI(ID_FILE_OPEN, OnUpdateFileOpen)
	ON_UPDATE_COMMAND_UI(ID_RENDER_SETTINGS, OnUpdateRenderSettings)
	ON_COMMAND(ID_MERGE_PROJECT, OnMergeProject)
	ON_UPDATE_COMMAND_UI(ID_MERGE_PROJECT, OnUpdateMergeProject)
	//}}AFX_MSG_MAP
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWinOSIApp construction

CWinOSIApp::CWinOSIApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CWinOSIApp object

CWinOSIApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CWinOSIApp initialization

BOOL CWinOSIApp::InitInstance()
{
  MEMORYSTATUS Mem; GlobalMemoryStatus(&Mem); sMGl=Mem.dwAvailVirtual;
	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	LoadStdProfileSettings();  // Load standard INI file options (including MRU)

	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views.

	CSingleDocTemplate* pDocTemplate;
	pDocTemplate = new CSingleDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(CWinOSIDoc),
		RUNTIME_CLASS(CMainFrame),       // main SDI frame window
		RUNTIME_CLASS(CWinOSIView));
	AddDocTemplate(pDocTemplate);

	// Parse command line for standard shell commands, DDE, file open
	char OpenFile[240]="\0";
	char SaveFile[240]="\0";
	if(__argc>1){
	  strcpy(OpenFile, __targv[1]);
	  if(__argc>2){
	    Passes=atoi(__targv[2]);
	    if(__argc>3){
	      strcpy(SaveFile, __targv[3]);
	      if(__argc>4){
	        VTime=(float)atof(__targv[4]);
		  }
	    }
	  }
	}

	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	// Dispatch commands specified on the command line
	if (!ProcessShellCommand(cmdInfo)) return FALSE;
    
	ViewPort->InitViewPort(XRes, YRes);
	if(OpenFile[0]){
	  Document->VMF.Load(OpenFile);
	  if(SaveFile[0]) OpenProject(SaveFile);
	  if(accu) OnRenderContinue(); else OnRenderStart();
	  if(SaveFile[0]) SaveProject(SaveFile);
	  if(Passes) return FALSE;
	}
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
		// No message handlers
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

// App command to run the dialog
void CWinOSIApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

/////////////////////////////////////////////////////////////////////////////
// CWinOSIApp commands

void CWinOSIApp::OnRenderStart() 
{
  RGB_Dbl *bptr; int x,y; nn=0; sRuns=0; sRays=0; sHits=0; sRTime=0; sIn=0;

  // allocate and clear accumulation buffer
  accu=new(RGB_Dbl[XRes*YRes]); sMBa=XRes*YRes*sizeof(RGB_Dbl);
  for(y=0; y<YRes; y++){
    bptr=accu+(y*XRes);
    for(x=0;x<XRes;x++){
      bptr[x].R=0.0;
      bptr[x].G=0.0;
      bptr[x].B=0.0;
    }
  }

  // allocate render buffer
  rend=new(RGB_Color[XRes*YRes]); Hits=0; dc=0.0;
  sMBr=XRes*YRes*sizeof(RGB_Color);

  Tint=RGB_Color(0.0f, 0.0f, 0.0f); 
  OnRenderContinue();
}

void CWinOSIApp::OnRenderContinue() 
{
  RGB_Dbl   *acuptr;
  RGB_Color *rndptr;
  int        x,y;
  vector     Pym,LPos,LNrm,LDir;
  RV_PrP     LightObj;
  float      val;

  if(!accu) OnRenderStart();
  if(!rend) {
    rend=new(RGB_Color[XRes*YRes]);
    sMBr=XRes*YRes*sizeof(RGB_Color);
  }

  vector N = unit(Document->VMF.CV.Target - Document->VMF.CV.Location);
  vector V = unit(Document->VMF.CV.Up-(Document->VMF.CV.Up%N)*N);
  vector U = N*V;

  float b     = 0.5f*Document->VMF.CV.h;
  float bx    = XRes<YRes? b : b*((float)XRes/(float)YRes)    ;
  float by    = XRes<YRes?     b*((float)YRes/(float)XRes) : b;

  pixelsize = (float)(bx / (double)XRes) * PixelRadius;
  
  vector VPorg = Document->VMF.CV.Location + N - bx*U - by*V;

  // Seed the random-number generator with current time so that
  // the numbers will be different every time we run.
  rndinit(time(NULL));

  // allocate hit-buffers
  sMTh=0;
  HBuffer=(HtPPtr *)new(HtPPtr[HitBuffers]); sMTh+=HitBuffers*sizeof(HtPPtr);
  for(y=0; y<HitBuffers; y++){
    HBuffer[y]=(HtPPtr)new(HitPoint[HBSize]); sMTh+=HBSize*sizeof(HitPoint);
  }

  RV_SceneTree=Document->BSPtree; RV_Environment=Document->VMF.Environment;

  float cpti=1.0f; Stop = FALSE; WaitTask(NULL);
  // calculate total global light emission
  sSLit=0; float GLI = CalcGLE(Document->BSPtree);
  PrLP p = Document->Invisibles;
  while(p){
	if(p->Prim->Mat->Emission.R > 0.0f){ GLI += p->Prim->Mat->Emission.R; sSLit++; }
    p=p->next;
  }
  if(GLI){
    // create light-emittor-list with statistically distibuted priorities
    CreateLL(Document->BSPtree, cpti, GLI); p = Document->Invisibles;;
    while(p){
	  if(p->Prim->Mat->Emission.R > 0.0f){
        LitePtr l      = new(Lite);
	            l->nxt = LiteRoot; LiteRoot=l;
	            l->obj = p->Prim;
	            l->pti = cpti; cpti -= p->Prim->Mat->Emission.R / GLI;
                l->lar = CalcArea(p->Prim);
	  }
      p=p->next;
	}
  } else {
	ViewPort->MessageBox("No Lights defined!","Error",MB_OK);
	Stop=true;
  }

  glhdc = ViewPort->GetDC(); if(ViewPort->use_palette) glhdc->SelectPalette(&(ViewPort->MyPalette), FALSE);

  time(&TStart);

  while(!Stop){
    // choose random wavelength from spectrum
	switch(nn){
	  case  0: wavlen=530.0f; break;
	  case  1: wavlen=660.0f; break;
	  case  2: wavlen=470.0f; break;
	  case  3: wavlen=590.0f; break;
	  case  4: wavlen=500.0f; break;
	  case  5: wavlen=410.0f; break;
	  default: wavlen=(float)(380.0+400.0*rnd());
	}
    // collect light hits
    ray_thresh=0.001f;
	pRays=0; pHits=0; pIn=0.0; HBi=0; HBp=0; SHTree.Clear(); sMTo=0;
    while((HBi<HitBuffers) && !Stop){
      // choose (statistically) random light-emitter
      cpti=(float)rnd(); LitePtr l=LiteRoot; while(cpti > l->pti) l=l->nxt; LightObj = l->obj;
      LPos = RV_RndPt(LightObj);
      if(StS_Light){
        LDir = crndhdir(LNrm=RV_PtNrm(LightObj,LPos));
        val  = 1.0f;
	  } else {
        LDir =  rndhdir(LNrm=RV_PtNrm(LightObj,LPos));
        val  = LNrm%LDir;
	  }
      RayTrace(&ThD, LightObj, NULL, &(Document->VMF.Environment), &LPos, &LDir, val, 0.0f, &PutPhoton, 0, SpecLightDepth);
      pRays++;
	} DrawSB(YRes,Stop? 0x888888 : 0x0000F0); WaitTask(NULL);
	// trace scene
    if(!Stop){
      ray_thresh=0.001f;
      static float xjt[]={0.0f, -0.4f,  0.4f, 0.4f, -0.4f, 0.0f,  0.0f, 0.4f, -0.4f };
      static float yjt[]={0.0f,  0.4f, -0.4f, 0.4f, -0.4f, 0.4f, -0.4f, 0.0f,  0.0f };
      float rx = (nn<9)? xjt[nn] : 1.1f*(float)rnd()-0.55f;
      float ry = (nn<9)? yjt[nn] : 1.1f*(float)rnd()-0.55f;
	  RV_Shader = &CallGetDiffuse; *RV_CamPtr = Document->VMF.CV.Location;
	  for(y=0; (y<YRes) && !Stop; y++){
        DrawSB(y,0x00F000);
        rndptr=rend+(y*XRes);
        Pym = VPorg + ((float)y+ry)/(float)YRes*2.0f*by*V - Document->VMF.CV.Location;
	    for(x=0; x<XRes; x++){
		  /*if((x==240) && (y==186)){
            x=240; // this is for debuging
		  }*/
          ThD.CamRay = unit(Pym + ((float)x+rx)*(2.0f/(float)XRes*bx*U));
          rndptr[x]  = RayTrace0(&ThD).R * WL2RGB(wavlen);
        }
		WaitTask(NULL);
      }
      DrawSB(YRes,Stop? 0x888888 : 0x00F000);
      if(!Stop){
        // add render buffer to accumulation buffer
	    for(y=0; y<YRes; y++){
          acuptr=accu+(y*XRes);
          rndptr=rend+(y*XRes);
	      for(x=0;x<XRes;x++){
            acuptr[x].R += rndptr[x].R;
            acuptr[x].G += rndptr[x].G;
            acuptr[x].B += rndptr[x].B;
          }
        }
		Tint += (pRays*WL2RGB(wavlen)); nn++; sRuns=nn;
		if(Passes && (nn>=Passes)) Stop=TRUE;
		// render buffer via bitmap to screen
		RenderImg(); sRays+=pRays; sHits+=pHits; sIn+=pIn;
		RTCurr=time(NULL)-TStart;

		if(projectInfo) projectInfo->Update();

        /*FILE *logfile;
        logfile = fopen("C:\\Temp\\WinOSi.log", "a");
        if(logfile){
          //fprintf(logfile,"%d;%d;%d;%f\n",sRuns,sRTime+RTCurr,sHits,sCtr);
          fprintf(logfile,"%3d;%f;%f;%f;%f;%f;%f;%f\n",sRuns,wavlen,WL2RGB(wavlen).R,WL2RGB(wavlen).G,WL2RGB(wavlen).B,Tint.R, Tint.G, Tint.B);
		}
		fclose(logfile);*/

	  }
    }
  }
  ViewPort->ReleaseDC(glhdc);
  sRTime+=RTCurr; RTCurr=0;

  // free Oct-tree
  SHTree.Kill(); sMTo=0;

  // free hit-buffers
  for(y=0; y<HitBuffers; y++){
    if(HBuffer[y]) delete(HBuffer[y]);
  }
  if(HBuffer) delete(HBuffer); sMTh=0;

  // free light-list
  LitePtr lp; while(LiteRoot){ lp=LiteRoot->nxt; delete(LiteRoot); LiteRoot=lp; }
  // free render-buffer
  if(rend){ delete(rend); rend=NULL; } sMBr=0;
  
  // free accumulation-buffer
  // if(accu) delete(accu); sMBa=0;
  // free scene memory
  // ObjPtr op; while(Scene){ op=Scene->next; delete(Scene->info); delete(Scene); Scene=op; }

  if(Exit){
    ((CFrameWnd *)MFrame)->DestroyWindow();
  }
}


void CWinOSIApp::OnRenderStop() 
{
  Stop = TRUE;
}

void CWinOSIApp::OnSaveProject() 
{
  OFName.lpstrFilter = "WinOSI projects (*.OSI)\000*.osi\000All Files  (*.*)\000*.*\000\000";
  OFName.lpstrDefExt = "OSI";
  if(strchr(OFName.lpstrFile,'.'))
    strcpy(strchr(OFName.lpstrFile,'.'),".OSI");
  else
	strcpy(strchr(OFName.lpstrFile, 0 ),".OSI");
  if(GetSaveFileName(&OFName)){
	SaveProject(OFName.lpstrFile);
  }
}

void CWinOSIApp::OnOpenProject() 
{
  OFName.lpstrFilter = "WinOSI projects (*.OSI)\000*.osi\000All Files  (*.*)\000*.*\000\000";
  OFName.lpstrDefExt = "OSI";
  if(strchr(OFName.lpstrFile,'.'))
    strcpy(strchr(OFName.lpstrFile,'.'),".OSI");
  else
	strcpy(strchr(OFName.lpstrFile, 0 ),".OSI");
  if(GetOpenFileName(&OFName)){
    OpenProject(OFName.lpstrFile);
  }
}

void CWinOSIApp::OnMergeProject() 
{
  OFName.lpstrFilter = "WinOSI projects (*.OSI)\000*.osi\000All Files  (*.*)\000*.*\000\000";
  OFName.lpstrDefExt = "OSI";
  if(strchr(OFName.lpstrFile,'.'))
    strcpy(strchr(OFName.lpstrFile,'.'),".OSI");
  else
	strcpy(strchr(OFName.lpstrFile, 0 ),".OSI");
  if(GetOpenFileName(&OFName)){
    MergeProject(OFName.lpstrFile);
  }
}

void CWinOSIApp::OnImageSettings() 
{
  if(!imageSettings){
	imageSettings = new ImgSet(NULL);
    imageSettings->Create(IDD_SETTINGS, NULL);
  }	else imageSettings->SetActiveWindow();
}

void CWinOSIApp::OnRenderSettings() 
{
  RendSet dlg; dlg.DoModal();
}

void CWinOSIApp::OnFileInfo() 
{
  if(!projectInfo){
	projectInfo = new PInfo(NULL);
    projectInfo->Create(IDD_Info, NULL);
  }	else projectInfo->SetActiveWindow();
}

// Menu control

void CWinOSIApp::OnUpdateRenderStop(CCmdUI* pCmdUI) 
{
  pCmdUI->Enable(Stop? 0 : 1);
}

void CWinOSIApp::OnUpdateAppExit(CCmdUI* pCmdUI) 
{
  pCmdUI->Enable(Stop? 1 : 0);
}

void CWinOSIApp::OnUpdateOpenProject(CCmdUI* pCmdUI) 
{
  pCmdUI->Enable((Document->BSPtree && Stop)? 1 : 0);	
}

void CWinOSIApp::OnUpdateSaveProject(CCmdUI* pCmdUI) 
{
  pCmdUI->Enable(accu? 1 : 0);	
}

void CWinOSIApp::OnUpdateRenderContinue(CCmdUI* pCmdUI) 
{
  pCmdUI->Enable((Document->BSPtree && Stop && accu)? 1 : 0);	
}

void CWinOSIApp::OnUpdateRenderStart(CCmdUI* pCmdUI) 
{
  pCmdUI->Enable((Document->BSPtree && Stop)? 1 : 0);	
}

void CWinOSIApp::OnUpdateFileOpen(CCmdUI* pCmdUI) 
{
  pCmdUI->Enable(Stop? 1 : 0);
}

void CWinOSIApp::OnUpdateRenderSettings(CCmdUI* pCmdUI) 
{
  pCmdUI->Enable(Stop? 1 : 0);
}

void CWinOSIApp::OnUpdateMergeProject(CCmdUI* pCmdUI) 
{
  pCmdUI->Enable((Document->VMF.Base && Stop && accu)? 1 : 0);	
}
