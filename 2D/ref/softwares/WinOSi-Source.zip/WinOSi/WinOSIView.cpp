// WinOSIView.cpp : implementation of the CWinOSIView class
//

#include "stdafx.h"
#include "general.h"
#include "Primitives.h"
#include "resource.h"
#include "RaVi.h"
#include "WinOSIDoc.h"
#include "WinOSIView.h"

extern "C" {
  #include "OpenImage.h"
}

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

typedef struct tagBITMAPINF8
{
  BITMAPINFOHEADER   bmiHeader;
  unsigned short int bmiColors[256];
} BITMAPINF8;

typedef struct tagBITMAPINF2
{
  BITMAPINFOHEADER   bmiHeader;
  unsigned short int bmiColors[2];
} BITMAPINF2;

CWinOSIView *ViewPort;

BITMAPINF8  BMPinf8;
BITMAPINF2  BMPinf2;
BOOL        DrawDIB_Initialized=FALSE;
int         colordepth;
BOOL        DDB=FALSE;

/////////////////////////////////////////////////////////////////////////////
// CWinOSIView

IMPLEMENT_DYNCREATE(CWinOSIView, CView)

BEGIN_MESSAGE_MAP(CWinOSIView, CView)
	//{{AFX_MSG_MAP(CWinOSIView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	ON_COMMAND(ID_IMAGE_COPY, OnImageCopy)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWinOSIView construction/destruction

CWinOSIView::CWinOSIView()
{
  ViewPort = this;
  BMPbits  = NULL;
}

CWinOSIView::~CWinOSIView() { }

BOOL CWinOSIView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CWinOSIView drawing

void CWinOSIView::OnDraw(CDC* pDC)
{
  CWinOSIDoc* pDoc = GetDocument(); ASSERT_VALID(pDoc);

  if(use_palette) pDC->SelectPalette(&MyPalette,FALSE);
  if(DDB){
    CDC mem; mem.CreateCompatibleDC(pDC);
    mem.SelectObject(bmp);
    pDC->BitBlt(0,0,BMPinfo.bmiHeader.biWidth,BMPinfo.bmiHeader.biHeight,&mem,0,0,SRCCOPY);
    mem.DeleteDC();
  }
}

/////////////////////////////////////////////////////////////////////////////
// CWinOSIView diagnostics

#ifdef _DEBUG
void CWinOSIView::AssertValid() const
{
	CView::AssertValid();
}

void CWinOSIView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CWinOSIDoc* CWinOSIView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CWinOSIDoc)));
	return (CWinOSIDoc*)m_pDocument;
}
#endif //_DEBUG


void CWinOSIView::DrawDIB_Init()
{
  LOGPALETTE   *pPalette;
  PALETTEENTRY  SysPal[20];
  HPALETTE      SysPalHd;
  byte          PalTag[256];
  HDC           hdcinfo;
  int           cdiff,cdiffmin,cmin;
  int           i,j,r,g,b;

  hdcinfo=CreateIC("DISPLAY",NULL,NULL,NULL);
  use_palette=(GetDeviceCaps(hdcinfo,RASTERCAPS) & RC_PALETTE);
  colordepth = GetDeviceCaps(hdcinfo,BITSPIXEL);
  DeleteDC(hdcinfo);

  if(use_palette){
    BMPinf8.bmiHeader.biSize          = sizeof(BITMAPINFOHEADER);
    BMPinf8.bmiHeader.biPlanes        = 1;
    BMPinf8.bmiHeader.biBitCount      = 8;
    BMPinf8.bmiHeader.biXPelsPerMeter = 0;
    BMPinf8.bmiHeader.biYPelsPerMeter = 0;
    BMPinf8.bmiHeader.biClrUsed       = 256;
    BMPinf8.bmiHeader.biClrImportant  = 256;
    for(i=0;i<256;i++){
      BMPinf8.bmiColors[i] = (unsigned short int)i;
      PalTag[i]=0;
    }
    pPalette=(LOGPALETTE *)malloc(sizeof(LOGPALETTE)+255*sizeof(PALETTEENTRY));
    pPalette->palVersion=0x300;
    pPalette->palNumEntries=256;
    for(r=0;r<8;r++){
      for(g=0;g<8;g++){
        for(b=0;b<4;b++){
          pPalette->palPalEntry[r+8*g+64*b].peRed  =16+32*r;
          pPalette->palPalEntry[r+8*g+64*b].peGreen=16+32*g;
          pPalette->palPalEntry[r+8*g+64*b].peBlue =32+64*b;
          pPalette->palPalEntry[r+8*g+64*b].peFlags=0;
        }
      }
    }
    // Palette bestm�glich an System-Palette anpassen
    SysPalHd=(struct HPALETTE__ *)GetStockObject(DEFAULT_PALETTE);
    GetPaletteEntries(SysPalHd,0,20,SysPal);
    for(i=0;i<20;i++){
      cdiffmin=25501;
      for(j=0;j<256;j++){
        if(PalTag[j]==0){
          cdiff=30*abs(pPalette->palPalEntry[j].peRed  -SysPal[i].peRed  )
               +59*abs(pPalette->palPalEntry[j].peGreen-SysPal[i].peGreen)
               +11*abs(pPalette->palPalEntry[j].peBlue -SysPal[i].peBlue );
          if(cdiff<cdiffmin){ cmin=j; cdiffmin=cdiff; }
        }
      }
      pPalette->palPalEntry[cmin]=SysPal[i];
      PalTag[cmin]=1;
    }
    MyPalette.CreatePalette(pPalette); free(pPalette);
    CDC *hdc = GetDC();
    hdc->SelectPalette(&MyPalette, FALSE);
    hdc->RealizePalette();
    ReleaseDC(hdc);
  } else {
    if(colordepth<24){
      BMPinf2.bmiHeader.biSize          = sizeof(BITMAPINFOHEADER);
      BMPinf2.bmiHeader.biPlanes        = 1;
      BMPinf2.bmiHeader.biBitCount      = colordepth;
      BMPinf2.bmiHeader.biXPelsPerMeter = 0;
      BMPinf2.bmiHeader.biYPelsPerMeter = 0;
      BMPinf2.bmiHeader.biClrUsed       = 0;
      BMPinf2.bmiHeader.biClrImportant  = 0;
    }
  }
  DrawDIB_Initialized=TRUE;
  WaitTask(NULL);
}


void CWinOSIView::MakeDDB(HBITMAP ddb, CDC *hdc, BITMAPINFO *BMPinfo, byte *BMPbits)
{
  static byte                SLBBuffer[1024];
  static unsigned short int  SLWBuffer[1024];
  static          short int  raster[4][4] = { {1,8,2,10},{14,6,13,4},{3,11,0,9},{12,5,15,7} };
  int                        x,y;
  byte                      *bitptr;
  int                        rp,gp,bp,rr,gr,br;

  if(use_palette){
    BMPinf8.bmiHeader.biWidth      =   BMPinfo->bmiHeader.biWidth;
    BMPinf8.bmiHeader.biHeight     =   BMPinfo->bmiHeader.biHeight;
    BMPinf8.bmiHeader.biSizeImage  = ((BMPinfo->bmiHeader.biWidth+3) & 0xFFFFFFFC);

    for(y=0;y<BMPinfo->bmiHeader.biHeight;y++){
      bitptr=BMPbits+(y*((BMPinfo->bmiHeader.biWidth*3+3) & 0xFFFFFFFC));
      for(x=0;x<BMPinfo->bmiHeader.biWidth;x++){
        bp=bitptr[3*x  ]>>6; br=((bitptr[3*x  ]>>2)&15); if( (bp<3) && (br>raster[x&3][y&3]) ) bp++;
        gp=bitptr[3*x+1]>>5; gr=((bitptr[3*x+1]>>1)&15); if( (gp<7) && (gr>raster[x&3][y&3]) ) gp++;
        rp=bitptr[3*x+2]>>5; rr=((bitptr[3*x+2]>>1)&15); if( (rp<7) && (rr>raster[x&3][y&3]) ) rp++;
        SLBBuffer[x]=(rp+8*gp+64*bp);
      }
      SetDIBits(hdc->m_hDC,ddb,y,1,SLBBuffer,(BITMAPINFO *)&BMPinf8,DIB_PAL_COLORS);
    }
  } else if(colordepth<24){
    BMPinf2.bmiHeader.biWidth      =   BMPinfo->bmiHeader.biWidth;
    BMPinf2.bmiHeader.biHeight     =   BMPinfo->bmiHeader.biHeight;
    BMPinf2.bmiHeader.biSizeImage  = ((BMPinfo->bmiHeader.biWidth*2+3) & 0xFFFFFFFC);

    for(y=0;y<BMPinfo->bmiHeader.biHeight;y++){
      bitptr=BMPbits+(y*((BMPinfo->bmiHeader.biWidth*3+3) & 0xFFFFFFFC));
      for(x=0;x<BMPinfo->bmiHeader.biWidth;x++){
        bp=bitptr[3*x  ]>>3; br=((bitptr[3*x  ]<<1)&15); if( (bp<31) && (br>raster[x&3][y&3]) ) bp++;
        gp=bitptr[3*x+1]>>3; gr=((bitptr[3*x+1]<<1)&15); if( (gp<31) && (gr>raster[x&3][y&3]) ) gp++;
        rp=bitptr[3*x+2]>>3; rr=((bitptr[3*x+2]<<1)&15); if( (rp<31) && (rr>raster[x&3][y&3]) ) rp++;
        SLWBuffer[x]=(bp+(gp<<5)+(rp<<10));
      }
      SetDIBits(hdc->m_hDC,ddb,y,1,SLWBuffer,(BITMAPINFO *)&BMPinf2,DIB_RGB_COLORS);
    }
  } else SetDIBits(hdc->m_hDC,ddb,0,BMPinfo->bmiHeader.biHeight,BMPbits,BMPinfo,DIB_RGB_COLORS);
}

void CWinOSIView::MakeDDBLine(int y, HBITMAP ddb, CDC *hdc, BITMAPINFO *BMPinfo, byte *BMPbits)
{
  static byte                SLBBuffer[1024];
  static unsigned short int  SLWBuffer[1024];
  static          short int  raster[4][4] = { {1,8,2,10},{14,6,13,4},{3,11,0,9},{12,5,15,7} };
  int                        x;
  byte                      *bitptr;
  int                        rp,gp,bp,rr,gr,br;

  bitptr=BMPbits+(y*((BMPinfo->bmiHeader.biWidth*3+3) & 0xFFFFFFFC));
  if(use_palette){
    for(x=0;x<BMPinfo->bmiHeader.biWidth;x++){
      bp=bitptr[3*x  ]>>6; br=((bitptr[3*x  ]>>2)&15); if( (bp<3) && (br>raster[x&3][y&3]) ) bp++;
      gp=bitptr[3*x+1]>>5; gr=((bitptr[3*x+1]>>1)&15); if( (gp<7) && (gr>raster[x&3][y&3]) ) gp++;
      rp=bitptr[3*x+2]>>5; rr=((bitptr[3*x+2]>>1)&15); if( (rp<7) && (rr>raster[x&3][y&3]) ) rp++;
      SLBBuffer[x]=(rp+8*gp+64*bp);
    }
    SetDIBits(hdc->m_hDC,ddb,y,1,SLBBuffer,(BITMAPINFO *)&BMPinf8,DIB_PAL_COLORS);
  } else if(colordepth<24){
    for(x=0;x<BMPinfo->bmiHeader.biWidth;x++){
      bp=bitptr[3*x  ]>>3; br=((bitptr[3*x  ]<<1)&15); if( (bp<31) && (br>raster[x&3][y&3]) ) bp++;
      gp=bitptr[3*x+1]>>3; gr=((bitptr[3*x+1]<<1)&15); if( (gp<31) && (gr>raster[x&3][y&3]) ) gp++;
      rp=bitptr[3*x+2]>>3; rr=((bitptr[3*x+2]<<1)&15); if( (rp<31) && (rr>raster[x&3][y&3]) ) rp++;
      SLWBuffer[x]=(bp+(gp<<5)+(rp<<10));
    }
    SetDIBits(hdc->m_hDC,ddb,y,1,SLWBuffer,(BITMAPINFO *)&BMPinf2,DIB_RGB_COLORS);
  } else SetDIBits(hdc->m_hDC,ddb,y,1,bitptr,BMPinfo,DIB_RGB_COLORS);
}


void CWinOSIView::InitViewPort(int XRes, int YRes) 
{
  BMPinfo.bmiHeader.biSize          = sizeof(BITMAPINFOHEADER);
  BMPinfo.bmiHeader.biWidth         = XRes;
  BMPinfo.bmiHeader.biHeight        = YRes;
  BMPinfo.bmiHeader.biPlanes        = 1;
  BMPinfo.bmiHeader.biBitCount      = 24;
  BMPinfo.bmiHeader.biCompression   = BI_RGB;
  BMPinfo.bmiHeader.biSizeImage     = YRes*((XRes*3+3) & 0xFFFFFFFC);
  BMPinfo.bmiHeader.biXPelsPerMeter = 0;
  BMPinfo.bmiHeader.biYPelsPerMeter = 0;
  BMPinfo.bmiHeader.biClrUsed       = 0;
  BMPinfo.bmiHeader.biClrImportant  = 0;

  BMPbits = (byte *)malloc(BMPinfo.bmiHeader.biSizeImage);

  CDC *hdc = GetDC(); if(use_palette) hdc->SelectPalette(&MyPalette,FALSE);
  bmp = CreateCompatibleBitmap(hdc->m_hDC,BMPinfo.bmiHeader.biWidth,BMPinfo.bmiHeader.biHeight);
  MakeDDB(bmp,hdc,&BMPinfo,BMPbits); DDB = TRUE;
  ReleaseDC(hdc);
}

/////////////////////////////////////////////////////////////////////////////
// CWinOSIView message handlers

BOOL CWinOSIView::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext) 
{
  if(CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext)) {
    if(!DrawDIB_Initialized) DrawDIB_Init();
	return TRUE;
  } else return FALSE;
}


void CWinOSIView::OnImageCopy() 
{
  CopyBitMap(&BMPinfo, BMPbits);
}
