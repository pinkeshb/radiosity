// RendSet.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// RendSet dialog

class RendSet : public CDialog
{
// Construction
public:
	RendSet(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(RendSet)
	enum { IDD = IDD_Render };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(RendSet)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(RendSet)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
