// Oct-tree-Library f�r WinOSI   07.10.1998 Michael Granz

#define FinStrtch2 0.527418f

#define MAXHPO 50  // maximum number of HitPoints per octant

typedef class OCTree *OCTPtr;

class OCTree
{
  private:

    HtPPtr  Hits;  // pointer to HitBuffers
    int     HPC;   // Hit-Point-Counter

	OCTPtr  LFB;  // pointer to Left -Front-Bottom Octant
    OCTPtr  RFB;  // pointer to Right-Front-Bottom Octant
    OCTPtr  LBB;  // pointer to Left -Back -Bottom Octant
    OCTPtr  RBB;  // pointer to Right-Back -Bottom Octant
    OCTPtr  LFT;  // pointer to Left -Front - Top  Octant
    OCTPtr  RFT;  // pointer to Right-Front - Top  Octant
    OCTPtr  LBT;  // pointer to Left -Back  - Top  Octant
    OCTPtr  RBT;  // pointer to Right-Back  - Top  Octant
    
	float   MinX,MaxX; // Dimensions of Oct-tree-Space
    float   MinY,MaxY;
    float   MinZ,MaxZ;

  public:

	 OCTree(){ Init(); }
	~OCTree(){ Kill(); }
	
	void Init(){
	  Hits=NULL; HPC=0;
	  LFB=NULL; RFB=NULL; LBB=NULL; RBB=NULL;
	  LFT=NULL; RFT=NULL; LBT=NULL; RBT=NULL;
	  MinX= 1e9f; MinY= 1e9f; MinZ= 1e9f;
	  MaxX=-1e9f; MaxY=-1e9f; MaxZ=-1e9f;
	}

	float GetVal(vector P, vector N, float d, int side, RV_PrP obj);
    void  Stretch(vector p);
	void  Finish();
    void  PutIn(HtPPtr p);
    void  Kill();
    void  Clear();
};

