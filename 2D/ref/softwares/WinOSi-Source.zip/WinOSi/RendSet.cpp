// RendSet.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "RendSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern int     XRes, YRes;
extern int     HitBuffers;
extern int     DiffDepth;
extern int     SpecLightDepth;
extern int     SpecViewDepth;
extern int     StS_Light, StS_Diff, StS_Sky;
extern float   PixelRadius;

extern void    ChgRes(int nXRes, int nYRes);

/////////////////////////////////////////////////////////////////////////////
// RendSet dialog


RendSet::RendSet(CWnd* pParent /*=NULL*/)
	: CDialog(RendSet::IDD, pParent)
{
	//{{AFX_DATA_INIT(RendSet)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void RendSet::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(RendSet)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(RendSet, CDialog)
	//{{AFX_MSG_MAP(RendSet)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// RendSet message handlers

BOOL RendSet::OnInitDialog() 
{
  CEdit*   pXRes = (CEdit*) GetDlgItem(IDC_EDIT_XRes);
  CEdit*   pYRes = (CEdit*) GetDlgItem(IDC_EDIT_YRes);
  CEdit*   pHBfs = (CEdit*) GetDlgItem(IDC_EDIT_HB);
  CEdit*   pSpLD = (CEdit*) GetDlgItem(IDC_EDIT_SpecLightDepth);
  CEdit*   pSpVD = (CEdit*) GetDlgItem(IDC_EDIT_SpecViewDepth);
  CEdit*   pDfDp = (CEdit*) GetDlgItem(IDC_EDIT_DiffDepth);
  CEdit*   pPR   = (CEdit*) GetDlgItem(IDC_EDIT_PRadius);
  CButton* pSL = (CButton*) GetDlgItem(IDC_StS_Lighting);
  CButton* pSD = (CButton*) GetDlgItem(IDC_StS_Diffuse);
  CButton* pSS = (CButton*) GetDlgItem(IDC_StS_SkyDome);
  char   buffer[8];

  CDialog::OnInitDialog();
  
  sprintf(buffer,"%6.4f", PixelRadius); pPR->SetWindowText(buffer);
  _itoa(XRes,           buffer, 10); pXRes->SetWindowText(buffer);
  _itoa(YRes,           buffer, 10); pYRes->SetWindowText(buffer);
  _itoa(HitBuffers,     buffer, 10); pHBfs->SetWindowText(buffer);
  _itoa(SpecLightDepth, buffer, 10); pSpLD->SetWindowText(buffer);
  _itoa(SpecViewDepth,  buffer, 10); pSpVD->SetWindowText(buffer);
  _itoa(DiffDepth,      buffer, 10); pDfDp->SetWindowText(buffer);
  if(StS_Light) pSL->SetCheck(1);
  if(StS_Diff)  pSD->SetCheck(1);
  if(StS_Sky)   pSS->SetCheck(1);

  return TRUE;
}

void RendSet::OnOK() 
{
  char   buffer[10]; int nXRes, nYRes;
  CButton* pSL = (CButton*) GetDlgItem(IDC_StS_Lighting); StS_Light=pSL->GetCheck();
  CButton* pSD = (CButton*) GetDlgItem(IDC_StS_Diffuse);  StS_Diff =pSD->GetCheck();
  CButton* pSS = (CButton*) GetDlgItem(IDC_StS_SkyDome);  StS_Sky  =pSS->GetCheck();
  CEdit*   pHBfs = (CEdit*) GetDlgItem(IDC_EDIT_HB            ); pHBfs->GetWindowText(buffer,8); HitBuffers       =        atoi(buffer);
  CEdit*   pSpLD = (CEdit*) GetDlgItem(IDC_EDIT_SpecLightDepth); pSpLD->GetWindowText(buffer,8); SpecLightDepth   =        atoi(buffer);
  CEdit*   pSpVD = (CEdit*) GetDlgItem(IDC_EDIT_SpecViewDepth ); pSpVD->GetWindowText(buffer,8); SpecViewDepth    =        atoi(buffer);
  CEdit*   pDfDp = (CEdit*) GetDlgItem(IDC_EDIT_DiffDepth     ); pDfDp->GetWindowText(buffer,8); DiffDepth        =        atoi(buffer);
  CEdit*   pPR   = (CEdit*) GetDlgItem(IDC_EDIT_PRadius       ); pPR  ->GetWindowText(buffer,8); PixelRadius      = (float)atof(buffer);
  CEdit*   pXRes = (CEdit*) GetDlgItem(IDC_EDIT_XRes          ); pXRes->GetWindowText(buffer,8); nXRes            =        atoi(buffer);
  CEdit*   pYRes = (CEdit*) GetDlgItem(IDC_EDIT_YRes          ); pYRes->GetWindowText(buffer,8); nYRes            =        atoi(buffer);

  CDialog::OnOK();

  ChgRes(nXRes, nYRes);  
}
