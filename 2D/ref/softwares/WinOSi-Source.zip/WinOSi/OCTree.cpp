// Oct-tree-Library f�r WinOSI   07.10.1998 Michael Granz

#include "stdafx.h"
#include "general.h"
#include "Primitives.h"
#include "RaVi.h"
#include "WinOSI.h"
#include "OCTree.h"

extern unsigned long int sMTo;

void OCTree::Stretch(vector p)
{
  if(p.x < MinX) MinX = (float)p.x;  if(p.x > MaxX) MaxX = (float)p.x;
  if(p.y < MinY) MinY = (float)p.y;  if(p.y > MaxY) MaxY = (float)p.y;
  if(p.z < MinZ) MinZ = (float)p.z;  if(p.z > MaxZ) MaxZ = (float)p.z;
}

void OCTree::Finish()
{
  MinX = 0.5f*(MinX+MaxX) - FinStrtch2*(MaxX-MinX);
  MinY = 0.5f*(MinY+MaxY) - FinStrtch2*(MaxY-MinY);
  MinZ = 0.5f*(MinZ+MaxZ) - FinStrtch2*(MaxZ-MinZ);
  MaxX = 0.5f*(MinX+MaxX) + FinStrtch2*(MaxX-MinX);
  MaxY = 0.5f*(MinY+MaxY) + FinStrtch2*(MaxY-MinY);
  MaxZ = 0.5f*(MinZ+MaxZ) + FinStrtch2*(MaxZ-MinZ);
}

void OCTree::PutIn(HtPPtr p)
{
  if(LFB){
    // decide to witch octant HitPoint has to be put
    if(p->pos.x > 0.5f*(MinX+MaxX)){
      if(p->pos.y > 0.5f*(MinY+MaxY)){
        if(p->pos.z > 0.5f*(MinZ+MaxZ)) RBT->PutIn(p); else RFT->PutIn(p);
      } else {
        if(p->pos.z > 0.5f*(MinZ+MaxZ)) RBB->PutIn(p); else RFB->PutIn(p);
      }
    } else {
      if(p->pos.y > 0.5f*(MinY+MaxY)){
        if(p->pos.z > 0.5f*(MinZ+MaxZ)) LBT->PutIn(p); else LFT->PutIn(p);
      } else {
        if(p->pos.z > 0.5f*(MinZ+MaxZ)) LBB->PutIn(p); else LFB->PutIn(p);
      }
    }
    HPC++;
  } else {
    // store HitPoint
    p->next = Hits;
    Hits    = p;
    // if maximum number of HitPoints is reached
    if(((++HPC)>=MAXHPO) && ((MaxX-MinX)>0.00001f)){
      // subdivide space into 8 octants
      float MidX = 0.5f*(MinX+MaxX);
      float MidY = 0.5f*(MinY+MaxY);
      float MidZ = 0.5f*(MinZ+MaxZ);
      LFB=new(OCTree); LFB->MinX=MinX; LFB->MaxX=MidX; LFB->MinY=MinY; LFB->MaxY=MidY; LFB->MinZ=MinZ; LFB->MaxZ=MidZ;
      RFB=new(OCTree); RFB->MinX=MidX; RFB->MaxX=MaxX; RFB->MinY=MinY; RFB->MaxY=MidY; RFB->MinZ=MinZ; RFB->MaxZ=MidZ;
      LBB=new(OCTree); LBB->MinX=MinX; LBB->MaxX=MidX; LBB->MinY=MinY; LBB->MaxY=MidY; LBB->MinZ=MidZ; LBB->MaxZ=MaxZ;
      RBB=new(OCTree); RBB->MinX=MidX; RBB->MaxX=MaxX; RBB->MinY=MinY; RBB->MaxY=MidY; RBB->MinZ=MidZ; RBB->MaxZ=MaxZ;
      LFT=new(OCTree); LFT->MinX=MinX; LFT->MaxX=MidX; LFT->MinY=MidY; LFT->MaxY=MaxY; LFT->MinZ=MinZ; LFT->MaxZ=MidZ;
      RFT=new(OCTree); RFT->MinX=MidX; RFT->MaxX=MaxX; RFT->MinY=MidY; RFT->MaxY=MaxY; RFT->MinZ=MinZ; RFT->MaxZ=MidZ;
      LBT=new(OCTree); LBT->MinX=MinX; LBT->MaxX=MidX; LBT->MinY=MidY; LBT->MaxY=MaxY; LBT->MinZ=MidZ; LBT->MaxZ=MaxZ;
      RBT=new(OCTree); RBT->MinX=MidX; RBT->MaxX=MaxX; RBT->MinY=MidY; RBT->MaxY=MaxY; RBT->MinZ=MidZ; RBT->MaxZ=MaxZ;
      sMTo += 8*sizeof(OCTree);
	  // distribute stored HitPoints to octants
      HtPPtr h1,h2=Hits;
      while(h2){
        h1=h2->next;
        if(h2->pos.x > MidX){
          if(h2->pos.y > MidY){
            if(h2->pos.z > MidZ) RBT->PutIn(h2); else RFT->PutIn(h2);
          } else {
            if(h2->pos.z > MidZ) RBB->PutIn(h2); else RFB->PutIn(h2);
          }
        } else {
          if(h2->pos.y > MidY){
            if(h2->pos.z > MidZ) LBT->PutIn(h2); else LFT->PutIn(h2);
          } else {
            if(h2->pos.z > MidZ) LBB->PutIn(h2); else LFB->PutIn(h2);
          }
        }
        h2=h1;
      }
      Hits=NULL;
    }
  }
}

void OCTree::Kill()
{
  if(LFB){ LFB->Kill(); delete LFB; LFB=NULL; }
  if(RFB){ RFB->Kill(); delete RFB; RFB=NULL; }
  if(LBB){ LBB->Kill(); delete LBB; LBB=NULL; }
  if(RBB){ RBB->Kill(); delete RBB; RBB=NULL; }
  if(LFT){ LFT->Kill(); delete LFT; LFT=NULL; }
  if(RFT){ RFT->Kill(); delete RFT; RFT=NULL; }
  if(LBT){ LBT->Kill(); delete LBT; LBT=NULL; }
  if(RBT){ RBT->Kill(); delete RBT; RBT=NULL; }
  Hits=NULL; HPC=0;
}

void OCTree::Clear()
{
  if(LFB)
  { 
  	LFB->Clear();
  	RFB->Clear();
  	LBB->Clear();
  	RBB->Clear();
  	LFT->Clear();
  	RFT->Clear();
  	LBT->Clear();
  	RBT->Clear();
  }
  Hits=NULL; HPC=0;
}

float OCTree::GetVal(vector P, vector N, float d, int side, RV_PrP obj)
{
  float Val = 0.0f;
  if(((P.x-d)>MaxX) || ((P.x+d)<MinX)) return Val;
  if(((P.y-d)>MaxY) || ((P.y+d)<MinY)) return Val;
  if(((P.z-d)>MaxZ) || ((P.z+d)<MinZ)) return Val;

  HtPPtr p=Hits;
  while(p){
	//if(p->obj->viss > (obj? -1 : 0)){ // object visible ?
      if(distance(P, p->pos) <= d){ // point inside sampling-area?
        if(p->side == side){        // point on right side of object ?
          Val += (p->val)/(Pi*d*d); // hits per area = W/m�
        }
	  }
	//}
	p=p->next;
  }

  float MidX = 0.5f*(MinX+MaxX);
  float MidY = 0.5f*(MinY+MaxY);
  float MidZ = 0.5f*(MinZ+MaxZ);
  
  //Do we really need to iterate all of these?
  /*
  if(LFB){
  	Val += LFB->GetVal(P, N, d, side, obj);
  	Val += RFB->GetVal(P, N, d, side, obj);
  	Val += LBB->GetVal(P, N, d, side, obj);
  	Val += RBB->GetVal(P, N, d, side, obj);
  	Val += LFT->GetVal(P, N, d, side, obj);
  	Val += RFT->GetVal(P, N, d, side, obj);
  	Val += LBT->GetVal(P, N, d, side, obj);
  	Val += RBT->GetVal(P, N, d, side, obj);
  }
  */
  
  // No, we dont, we only need to iterate the ones in which possible hits could be found! 
  // 2005 Nathan Cain

  if(LFB)
  {
        if(P.x >= MidX - d){
          if(P.y >= MidY - d)
          {
            	if(P.z >= MidZ - d)
            		Val += RBT->GetVal(P, N, d, side, obj);
            	if(P.z <= MidZ + d)
            		Val += RFT->GetVal(P, N, d, side, obj);
          }
          if(P.y <= MidY + d)
          {
            	if(P.z >= MidZ - d)
            		Val += RBB->GetVal(P, N, d, side, obj);
            	if(P.z <= MidZ + d)
            		Val += RFB->GetVal(P, N, d, side, obj);
          }
        }
        if(P.x <= MidX + d)
        {
          if(P.y >= MidY - d)
          {
            	if(P.z >= MidZ - d)
            		Val += LBT->GetVal(P, N, d, side, obj);
            	if(P.z <= MidZ + d)
            		Val += LFT->GetVal(P, N, d, side, obj);
          }
          if(P.y <= MidY + d)
          {
            	if(P.z >= MidZ - d)
            		Val += LBB->GetVal(P, N, d, side, obj);
            	if(P.z <= MidZ + d)
            		Val += LFB->GetVal(P, N, d, side, obj);
          }
        }
   }

  return Val;
}
