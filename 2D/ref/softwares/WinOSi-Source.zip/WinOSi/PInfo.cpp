// PInfo.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "PInfo.h"
#include <time.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern time_t RTCurr;
extern time_t sRTime;
extern __int64 sRays,sHits;
extern unsigned long int  sRuns;
extern unsigned long int  sMBa,sMBr,sMGl;
extern unsigned long int  sMTh,sMTo;
extern          long int  sSMat,sSMap,sSObj,sSLit;
extern          long int  sSMem;
extern double             sOut,sIn;
extern double             sCtr,sDif;

PInfo* projectInfo=NULL;

/////////////////////////////////////////////////////////////////////////////
// PInfo dialog


PInfo::PInfo(CWnd* pParent /*=NULL*/)
	: CDialog(PInfo::IDD, pParent)
{
	//{{AFX_DATA_INIT(PInfo)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void PInfo::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(PInfo)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(PInfo, CDialog)
	//{{AFX_MSG_MAP(PInfo)
	ON_BN_CLICKED(IDC_OK, OnOk)
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

void Time2Str(char *text, time_t t)
{
  long h=t/3600;
  long m=t/60-60*h;
  long s=t-3600*h-60*m;
  text[0]= (h/100)? '0'+h/100 : ' ';
  text[1]='0'+(h-100*(h/100))/10; text[2]='0'+h-10*(h/10); text[3]=':';
  text[4]='0'+ m             /10; text[5]='0'+m-10*(m/10); text[6]=':';
  text[7]='0'+ s             /10; text[8]='0'+s-10*(s/10); text[9]= 0 ;
}

/////////////////////////////////////////////////////////////////////////////
// PInfo message handlers

void PInfo::OnOk() 
{
  DestroyWindow(); projectInfo=NULL;
}

void PInfo::OnClose() 
{
  CDialog::OnClose();
  projectInfo=NULL;
}

void PInfo::Update() 
{
  char     buffer[12];
  MEMORYSTATUS Mem; GlobalMemoryStatus(&Mem); long int TM=sMGl-Mem.dwAvailVirtual;
  CStatic* tGTim = (CStatic*) GetDlgItem(IDC_ToTime);   Time2Str(buffer,sRTime+RTCurr); tGTim->SetWindowText(buffer);
  CStatic* tTTim = (CStatic*) GetDlgItem(IDC_ThTime);   Time2Str(buffer,RTCurr); tTTim->SetWindowText(buffer);
  CStatic* tEIn  = (CStatic*) GetDlgItem(IDC_EIn);      sprintf(buffer,"%10.2lf", sIn ); tEIn->SetWindowText(buffer);
  CStatic* tEOut = (CStatic*) GetDlgItem(IDC_EOut);     sprintf(buffer,"%10.2lf", sOut); tEOut->SetWindowText(buffer);
  CStatic* tRays = (CStatic*) GetDlgItem(IDC_Rays);     sprintf(buffer,"%d", sRays); tRays->SetWindowText(buffer);
  CStatic* tHits = (CStatic*) GetDlgItem(IDC_Hits);     sprintf(buffer,"%d", sHits); tHits->SetWindowText(buffer);
  CStatic* tSMem = (CStatic*) GetDlgItem(IDC_MScene);   sprintf(buffer,"%d", sSMem); tSMem->SetWindowText(buffer);
  CStatic* tSMap = (CStatic*) GetDlgItem(IDC_MMaps);    sprintf(buffer,"%d", (sSMap/1024)); tSMap->SetWindowText(buffer);
  CStatic* tBMem = (CStatic*) GetDlgItem(IDC_MBuffers); sprintf(buffer,"%d", (sMBa+sMBr)/1024); tBMem->SetWindowText(buffer);
  CStatic* tTMem = (CStatic*) GetDlgItem(IDC_MOctree);  sprintf(buffer,"%d", (sMTh+sMTo)/1024); tTMem->SetWindowText(buffer);
  CStatic* tGMem = (CStatic*) GetDlgItem(IDC_MTotal);   sprintf(buffer,"%d", (TM)/1024); tGMem->SetWindowText(buffer);
  CStatic* tSObj = (CStatic*) GetDlgItem(IDC_SObj);     sprintf(buffer,"%d", sSObj); tSObj->SetWindowText(buffer);
  CStatic* tSMat = (CStatic*) GetDlgItem(IDC_SMat);     sprintf(buffer,"%d", sSMat); tSMat->SetWindowText(buffer);
  CStatic* tSLit = (CStatic*) GetDlgItem(IDC_SLit);     sprintf(buffer,"%d", sSLit); tSLit->SetWindowText(buffer);
  CStatic* tRuns = (CStatic*) GetDlgItem(IDC_Runs);     sprintf(buffer,"%d", sRuns); tRuns->SetWindowText(buffer);
  CStatic* tCntr = (CStatic*) GetDlgItem(IDC_Cntr);     sprintf(buffer,"%2.4f", sCtr); tCntr->SetWindowText(buffer);
  CStatic* tDiff = (CStatic*) GetDlgItem(IDC_Diff);     sprintf(buffer,"%2.4f", sDif); tDiff->SetWindowText(buffer);
  CStatic* tHpR  = (CStatic*) GetDlgItem(IDC_HpR);
  CStatic* tHps  = (CStatic*) GetDlgItem(IDC_Hps);
  CStatic* tRps  = (CStatic*) GetDlgItem(IDC_Rps);
  CStatic* tENy  = (CStatic*) GetDlgItem(IDC_ENy);
  if(sRays>0){
    sprintf(buffer,"%4.2f", (float)sHits/(float)sRays);
    tHpR->SetWindowText(buffer);
  } else tHpR->SetWindowText("0.00");
  if((sRTime+RTCurr)>0){
    sprintf(buffer,"%d", sRays/(sRTime+RTCurr)); tRps->SetWindowText(buffer);
    sprintf(buffer,"%d", sHits/(sRTime+RTCurr)); tHps->SetWindowText(buffer);
  } else {
	tRps->SetWindowText("0");
	tHps->SetWindowText("0");
  }
  if(sIn>0){
    sprintf(buffer,"%4.2f", sOut/sIn);
    tENy->SetWindowText(buffer);
  } else tENy->SetWindowText("0.00");
}


BOOL PInfo::OnInitDialog() 
{
  CDialog::OnInitDialog();
  Update();
  
  return TRUE;  // return TRUE unless you set the focus to a control
                // EXCEPTION: OCX Property Pages should return FALSE
}
