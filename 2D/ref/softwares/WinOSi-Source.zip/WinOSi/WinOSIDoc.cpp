// WinOSIDoc.cpp : implementation of the CWinOSIDoc class
//

#include "stdafx.h"
#include "general.h"
#include "Primitives.h"
#include "resource.h"

#include "RaVi.h"
#include "RaVi_Tree.h"

#include "WinOSI.h"
#include "OCTree.h"
#include "PInfo.h"

#include "WinOSIDoc.h"
#include "WinOSIView.h"

extern "C" {
  #include "OpenImage.h"
}

#ifdef _DEBUG
  #define new DEBUG_NEW
  #undef THIS_FILE
  static char THIS_FILE[] = __FILE__;
#endif

extern OCTree SHTree;   // Main Scene and HitBuffer Oct-tree

CWinOSIDoc   *Document;

OPENFILENAME  OFName;
char          filename[320] = "";

long int      sSMem=0,sSMap=0,sSObj=0,sSMat=0,sSLit=0;
ushort        OGLP;

extern BSPplane *VM2RaVi(PrimPtr p);
extern PrLP      Prim2RV(PrimPtr p);

/////////////////////////////////////////////////////////////////////////////
// CWinOSIDoc

IMPLEMENT_DYNCREATE(CWinOSIDoc, CDocument)

BEGIN_MESSAGE_MAP(CWinOSIDoc, CDocument)
	//{{AFX_MSG_MAP(CWinOSIDoc)
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
	ON_COMMAND(ID_FILE_SAVE_IMG, OnFileSaveImg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWinOSIDoc construction/destruction

CWinOSIDoc::CWinOSIDoc()
{
  OFName.lStructSize = sizeof(OPENFILENAME);
  OFName.hwndOwner = NULL;
  OFName.lpstrCustomFilter = NULL;
  OFName.nFilterIndex = 1;
  OFName.lpstrFile = filename;
  OFName.nMaxFile = sizeof(filename);
  OFName.lpstrFileTitle = NULL;
  OFName.lpstrInitialDir = NULL;
  OFName.lpstrTitle = NULL;
  OFName.Flags = 0;
  OFName.nFileOffset = 0;
  OFName.nFileExtension = 0;
  OFName.lpfnHook = NULL;
  
  BSPtree = NULL;

  Document = this;
}

CWinOSIDoc::~CWinOSIDoc() { }

/////////////////////////////////////////////////////////////////////////////
// CWinOSIDoc diagnostics

#ifdef _DEBUG
  void CWinOSIDoc::AssertValid() const
  {
    CDocument::AssertValid();
  }

  void CWinOSIDoc::Dump(CDumpContext& dc) const
  {
    CDocument::Dump(dc);
  }
#endif //_DEBUG


/////////////////////////////////////////////////////////////////////////////
// CWinOSIDoc commands

void CWinOSIDoc::OnFileOpen() 
{
  OFName.lpstrFilter = "Virtual Models  (*.VMD)\000*.vmd\000All Files  (*.*)\000*.*\000\000";
  OFName.lpstrDefExt = "vmd";
  if(GetOpenFileName(&OFName)){
    sSMem=0,sSMap=0,sSObj=0,sSMat=0,sSLit=0;
    VMF.Init(); VMF.Load(filename); BSPtree=VM2RaVi(VMF.Base); RV_Init(); Invisibles=Prim2RV(VMF.Hidden);

    SHTree.Stretch(RV_BBMin); SHTree.Stretch(RV_BBMax); SHTree.Finish();

    for(MatPtr mp=VMF.MatList; mp; mp=mp->next){
      sSMat++; sSMem += sizeof(Material)+strlen(mp->name)+1;
	  if(mp->Texture){
		sSMem += sizeof(TexMap)+strlen(mp->Texture->tname)+1;
		char texpath[260]; strcpy(texpath,filename);
        char *p = strrchr(texpath,'\\'); if(!p) p = strrchr(texpath,':'); p = p? p+1 : texpath;
        strcpy(p,mp->Texture->tname);
        mp->Texture->tbits = LoadImageFile(texpath, &(mp->Texture->tinfo));
		sSMap += mp->Texture->tinfo.bmiHeader.biSizeImage;
        //if(!(mat->Texture->tbits)) TextWin.Output(3,"- couldn't load texture: '%s'!\n",texpath);
	  }
	}
	if(projectInfo) projectInfo->Update();
  }
}

void CWinOSIDoc::OnFileSaveImg() 
{
  SaveBitMap(NULL, &(ViewPort->BMPinfo), ViewPort->BMPbits);
}

