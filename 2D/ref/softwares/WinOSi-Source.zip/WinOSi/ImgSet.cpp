// ImgSet.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "ImgSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern float   RelExp;
extern double  Gamma;

extern void    RenderImg();

ImgSet*   imageSettings=NULL;

/////////////////////////////////////////////////////////////////////////////
// ImgSet dialog


ImgSet::ImgSet(CWnd* pParent /*=NULL*/)
	: CDialog(ImgSet::IDD, pParent)
{
	//{{AFX_DATA_INIT(ImgSet)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void ImgSet::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(ImgSet)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(ImgSet, CDialog)
	//{{AFX_MSG_MAP(ImgSet)
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_OK, OnOk)
	ON_BN_CLICKED(IDC_Preview, OnPreview)
	ON_BN_CLICKED(IDC_Cancel, OnCancel)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// ImgSet message handlers

void ImgSet::OnClose() 
{
  CDialog::OnClose();
  imageSettings=NULL;
}

void ImgSet::OnOk() 
{
  CEdit* pExpRel = (CEdit*) GetDlgItem(IDC_ExpRel);
  CEdit* pGamma  = (CEdit*) GetDlgItem(IDC_Gamma );
  char   buffer[8];
  pExpRel->GetWindowText(buffer,8);
  if(atof(buffer)) RelExp=(float)atof(buffer);	
  pGamma ->GetWindowText(buffer,8);
  if(atof(buffer)) Gamma =(float)atof(buffer);	

  DestroyWindow(); imageSettings=NULL;
  RenderImg();
}

void ImgSet::OnCancel() 
{
  RelExp=OldRE; Gamma=OldGm;
  DestroyWindow(); imageSettings=NULL;
  RenderImg();
}

BOOL ImgSet::OnInitDialog() 
{
  CEdit* pExpRel = (CEdit*) GetDlgItem(IDC_ExpRel); OldRE=RelExp;
  CEdit* pGamma  = (CEdit*) GetDlgItem(IDC_Gamma ); OldGm=Gamma;
  char   buffer[8];

  CDialog::OnInitDialog();
	
  sprintf(buffer,"%5.3f", RelExp);
  pExpRel->SetWindowText(buffer);
  sprintf(buffer,"%3.1f", Gamma );
  pGamma ->SetWindowText(buffer);
	
  return TRUE;  // return TRUE unless you set the focus to a control
                // EXCEPTION: OCX Property Pages should return FALSE
}

void ImgSet::OnPreview() 
{
  CEdit* pExpRel = (CEdit*) GetDlgItem(IDC_ExpRel);
  CEdit* pGamma  = (CEdit*) GetDlgItem(IDC_Gamma );
  char   buffer[8];
  pExpRel->GetWindowText(buffer,8);
  if(atof(buffer)) RelExp=(float)atof(buffer);	
  pGamma ->GetWindowText(buffer,8);
  if(atof(buffer)) Gamma =(float)atof(buffer);
  RenderImg();
}

