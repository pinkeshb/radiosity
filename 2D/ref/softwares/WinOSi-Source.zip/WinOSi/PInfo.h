// PInfo.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// PInfo dialog

class PInfo : public CDialog
{
// Construction
public:
	PInfo(CWnd* pParent = NULL);   // standard constructor
    void Update();

// Dialog Data
	//{{AFX_DATA(PInfo)
	enum { IDD = IDD_Info };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(PInfo)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(PInfo)
	afx_msg void OnOk();
	afx_msg void OnClose();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

extern PInfo*   projectInfo;
